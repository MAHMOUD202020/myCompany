<?php
return [

    "line"      => "10 lines",
    "lines"     => "line :number",
    "desc"      => "Descending Order",
    "asc"       => "Ascending order",
    "print"     => "Print",
    "reload"    => "Reloading",
    "action"    => "control",
    "selectAll" => "select all",
    "deselect"  => "uncheck",
    "add"       => "addition",
    "change"    => "Selection",
    "edit"      => "Modification",
    "delete"    => "delete",
    "restore"   => "Recovery",
    'csv'       => 'export to excel',
    'json'      => 'export to json',
    'pdf'       => 'export pdf',
    'empty'     => 'There is no data to display',

    "myDataTableAction"   => "action",
    "restoreSelected"     => "prepared limiter",
    "deleteSelected"      => "delete selector",
    "printSelected"       => 'selector print',
    "searchInDataShowNow" => "Search the displayed data",

];
