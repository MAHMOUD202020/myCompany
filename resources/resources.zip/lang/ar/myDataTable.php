<?php
return [

    "line" => "10 سطور",
    "lines" => ":number سطر",
    "desc" => "ترتيب تنازلي",
    "asc" => "ترتيب تصاعدي",
    "print" => "طباعة",
    "reload" => "اعادة تحميل",
    "searchId"=>"بحث بالمعرف",
    "action"=>"التحكم",
    "selectAll"=>"تحديد الكل",
    "deselect" => "الغاء التحديد",
    "myDataTableAction" => "action",
    "add"=>"اضافة",
    "change"=>"اختيار",
    "edit"=>"تعديل",
    "delete"=>"حذف",
    "restore" => "استعاده",
    "restoreSelected" => "استعدة المحدد",
    "deleteSelected" => "حذف المحدد",
    "printSelected" => "طباعة المحدد",
    "searchInDataShowNow" => "البحث في البيانات المعروضه",
    'csv' => 'تصدير الي excel',
    'json' => 'تصدير الي  json',
    'pdf' => 'تصدير ال pdf',
    'empty' => 'لاتوجد اي بيانات لعرضها'

];
