<form method="post" action="{{ route('admin.partners.store')}}" enctype="multipart/form-data">
    @csrf
    <div class="form-row mb-4">

        <div class="form-group col-md-6">
            <label for="name">@lang('form.label.name ar')</label>
            <input name="name" type="text" maxlength="50" class="form-control @error('name') is-invalid @enderror" id="name" placeholder="اسم يدل علي الشريك" value="{{old('name')}}" required>
            @error('name')<span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span>@enderror
        </div>

        <div class="form-group col-md-6">
            <label for="url">@lang('form.label.link') (اختياري) </label>
            <input name="url" type="text" maxlength="255" class="form-control @error('url') is-invalid @enderror" id="url" placeholder="رابط التوجية" value="{{old('url')}}">
            @error('url')<span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span>@enderror
        </div>

        <div class="form-group col-md-12">
            <label for="icon">@lang('form.label.icon')</label>
            <input name="icon" type="file" maxlength="255" class="form-control @error('icon') is-invalid @enderror" id="icon" placeholder="@lang('form.label.user icon')" value="{{old('icon')}}" required>
            @error('icon')<span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span>@enderror
        </div>

    </div>

    <button type="submit" class="btn btn-primary mt-3">@lang('layout.add partner')</button>
</form>
