@php($dir = app()->getLocale() === 'ar' ? 'rtl': 'ltr')

<!doctype html>
<html lang="ar" dir="{{$dir}}">
<head>


    @include('web.layouts.meta')

    <title>excape egypt | اكسيب ايجبت</title>

    @include('web.layouts.style')

    @yield('css')

</head>

<body>

    @include('web.layouts.preloader')

    @include('web.layouts.switch')

    @include('web.layouts.navbar')

    <!-- Page Wrapper End -->
    <div class="page-wrapper">

        @if(isset($page) && $page == 'home')
            <!-- start content -->
            @yield('content')
            <!-- end content -->
        @else
            <div class="content-wrapper">
                <!-- start content -->
                @yield('content')
                <!-- end content -->
            </div>
        @endif

        @include('web.layouts.footer')

    </div>
    <!-- Page Wrapper End -->


    @include('web.layouts.script')

    @yield('js')

</body>

</html>
