<!-- Back-to-top button Start -->
<a href="javascript:void(0)" class="back-to-top bounce"><i class="ri-arrow-up-s-line"></i></a>
<!-- Back-to-top button End -->

<!-- Link of JS files -->
<script src="{{asset('assets/web/js/jquery.min.js')}}"></script>
<script src="{{asset('assets/web/js/bootstrap.bundle.min.js')}}"></script>
{{--<script src="{{'assets/web/js/form-validator.min.js'}}"></script>--}}
{{--<script src="{{'assets/web/js/contact-form-script.js'}}"></script>--}}
{{--<script src="{{'assets/web/js/aos.js'}}"></script>--}}
{{--<script src="{{'assets/web/js/owl.carousel.min.js'}}"></script>--}}
{{--<script src="{{'assets/web/js/jquery.appear.js'}}"></script>--}}
{{--<script src="{{'assets/web/js/tweenmax.min.js'}}"></script>--}}
{{--<script src="{{'assets/web/js/main.js'}}"></script>--}}
<script src="{{asset('assets/web/js/all.js')}}"></script>

<script>
    setTimeout(function () {
        $('.js-preloader').hide(250);
    }, 500)

    $(function () {


        $('.loading-lazy-1').each(function(){
            $(this).attr('src', $(this).attr('data-src'));
        })

        $('.loading-lazy-bg').each(function(){
            $(this).css('background-image', 'url(' + $(this).attr('data-src') + ')');
        })

        $('.loading-lazy-2').each(function(){
            $(this).attr('src', $(this).attr('data-src'));
        })

        $('.loading-lazy-3').each(function(){
            $(this).attr('src', $(this).attr('data-src'));
        })


        setTimeout(function(){
            $('.loading-lazy-4').each(function(){
                $(this).attr('src', $(this).attr('data-src'));
            })
        }, 1000)

        $('#contactForm').on('submit', function (e) {

            e.preventDefault();

            if($('.help-block').text().length == 0){

                form = this;

                $.ajax({
                    headers: {
                        'X-CSRF-TOKEN': '{{csrf_token()}}'
                    },
                    method:'POST',
                    url: '{{route('web.sendMessage')}}',
                    data:$(this).serialize(),

                    success($xhr){
                        location.href = '{{url('')}}'+'/sendMessage/success/'+$xhr
                    },

                    error($xhr){
                        alert($xhr.responseJSON.message)
                    }
                })
            }

        })
    })

</script>
