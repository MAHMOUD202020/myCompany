<ul class="social-profile list-style style1">
    <li>
        <a target="_blank" href="https://twitter.com/ExcapeEgypt">
            <i class="ri-twitter-line"></i>
        </a>
    </li>
    <li>
        <a target="_blank" href="https://www.facebook.com/excapeegypt">
            <i class="ri-facebook-line"></i>
        </a>
    </li>
    <li>
        <a target="_blank" href="https://www.linkedin.com/company/excape-eg">
            <i class="ri-linkedin-line"></i>
        </a>
    </li>

    <li>
        <a target="_blank" href="https://www.linkedin.com/company/excape-eg">
            <i class="ri-linkedin-line"></i>
        </a>
    </li>

    <li>
        <a target="_blank" href="https://www.instagram.com/excape_egypt">
            <i class="ri-instagram-line"></i>
        </a>
    </li>

    <li>
        <a target="_blank" href="https://www.behance.net/excapeegypt">
            <i class="ri-behance-line"></i>
        </a>
    </li>
    <li>
        <a target="_blank" href="https://api.whatsapp.com/send/?phone=966596920000">
            <i class="ri-whatsapp-line"></i>
        </a>
    </li>
</ul>
