<meta charset="utf-8">


<meta name="title" content="excape egypt | اكسيب ايجبت">
<meta name="description" content="Excape Egypt: هي وكالة مبادرة التسويق الداخلي في مصر  تهدف إلى تغيير الطريقة التي يقوم بها المصريون بالتسويق ورفع مفهومهم عن التسويق. لقد عملنا مع أكثر من 100 عميل في مجالات مختلفة">
<meta name="keywords" content="تسويق -التسويق - التسويق الالكتروني - برمجة المواقع - برمجة - تصميم - ادارة - مصر - القاهره - الزقازيق - الرياض - السعودية">
<meta name="robots" content="index, follow">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="language" content="Arabic">

<!-- Open Graph / Facebook -->
<meta property="og:type" content="website">
<meta property="og:url" content="https://www.facebook.com/excapeegypt">
<meta property="og:title" content="excape egypt | اكسيب ايجبت">
<meta property="og:description" content="Excape Egypt: هي وكالة مبادرة التسويق الداخلي في مصر تهدف إلى تغيير الطريقة التي يقوم بها المصريون بالتسويق ورفع مفهومهم عن التسويق. لقد عملنا مع أكثر من 100 عميل في مجالات مختلفة">
<meta property="og:image" content="{{asset('assets/web/images/Excape-EGYPT.jpg')}}">

<!-- Twitter -->
<meta property="twitter:card" content="summary_large_image">
<meta property="twitter:url" content="https://twitter.com/ExcapeEgypt">
<meta property="twitter:title" content="excape egypt | اكسيب ايجبت">
<meta property="twitter:description" content="Excape Egypt: هي وكالة مبادرة التسويق الداخلي في مصر تهدف إلى تغيير الطريقة التي يقوم بها المصريون بالتسويق ورفع مفهومهم عن التسويق. لقد عملنا مع أكثر من 100 عميل في مجالات مختلفة">
<meta property="twitter:image" content="{{asset('assets/web/images/Excape-EGYPT.jpg')}}">

<meta name="csrf-token" content="{{ csrf_token() }}">

<meta name="format-detection" content="telephone=no">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<link rel="icon" href="{{asset('assets/web/images/logo2.jpg')}}">
