<link rel="stylesheet" href="{{asset('assets/web/css/bootstrap.rtl.min.css')}}">
{{--<link rel="stylesheet" href="{{asset('assets/web/css/flaticon.css')}}">--}}
{{--<link rel="stylesheet" href="{{asset('assets/web/css/remixicon.css')}}">--}}
{{--<link rel="stylesheet" href="{{asset('assets/web/css/owl.carousel.min.css')}}">--}}
{{--<link rel="stylesheet" href="{{asset('assets/web/css/aos.css')}}">--}}
{{--<link rel="stylesheet" href="{{asset('assets/web/css/style.css')}}">--}}
{{--<link rel="stylesheet" href="{{asset('assets/web/css/responsive.css')}}">--}}
{{--<link rel="stylesheet" href="{{asset('assets/web/css/dark-theme.css')}}">--}}
{{--<link rel="stylesheet" href="{{asset('assets/web/css/rtl.css')}}">--}}
<link rel="stylesheet" href="{{asset('assets/web/css/all.css')}}">
<link rel="stylesheet" href="{{asset('assets/web/css/style.min.css')}}">
<link rel="stylesheet" href="{{asset('assets/web/css/all2.css')}}">

<link rel="icon" type="image/png" href="{{asset('assets/web/images/logo2.jpg')}}">

<style>
    .hero-slide-item{
        background-position-y: 25% !important;
    }

    #contactForm select {
        height: 60px;
        color: black !important;
        background-color: white;
        border: 1px solid #ccd4dd;
    }


    .bg-prussian {
        background: linear-gradient(90deg, rgb(45 61 111 / 91%) 0%, #2D3D6F 100%) !important;
        opacity: 1 !important;
    }

    .hero-wrap.style5 .hero-img-wrap .hero-img-one, .hero-wrap.style5 .hero-img-wrap .hero-img-two {
        width: calc(60% - 10px);
        margin-top: 0;
    }

    .service-card.style6:hover,
    .gallery-card .gallery-info .gallery-icon,
    .service-card.style1:hover .service-info span{
        background-color: #2d3d6f !important;
    }

    .service-card.style6:hover .service-info h3{
        color: white !important;
    }

    #contactForm .btn.style2,
    .btn-primary:hover
    {
        background-color: #1b274b !important
    }
    @media (max-width:767px) {
        #subTitle{
            font-size: 18px !important;
            height: 55px;
        }

        #btnHeaderContact{
            width: 40% !important;
        }

        #btnHeaderWhatsapp{
            width: 55% !important;
        }

        .space-phone{
            height: 65px;
        }
        .header-wrap.style4 .header-top .header-top-right .social-profile:after{
            display: none;
        }
        .header-top{
            text-align: right;
        }
        .header-top-right{
            justify-content: flex-start !important;
        }

        .footer-bottom .social-link h6 {
            margin: 0 0 10px 10px;
        }

        .header-wrap.style5 .navbar-toggler{
            background-color: white;
        }
    }

    @media (min-width: 1024px) {
        .hero-wrap.style5 .hero-img-wrap .hero-img-one, .hero-wrap.style5 .hero-img-wrap .hero-img-two {
            width: calc(70% - 10px);
            margin-top: 50px;
        }
    }

    body::-webkit-scrollbar {
        width: 5px;
    }

    body::-webkit-scrollbar-track {
        background-color: #2D3D6F;
        border-radius: 100px;
    }

    body::-webkit-scrollbar-thumb {
        background-color: #3F88C5;
        border-radius: 100px;
    }
</style>
