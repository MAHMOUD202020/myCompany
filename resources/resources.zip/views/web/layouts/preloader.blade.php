<!--Preloader starts-->
<div class="preloader js-preloader">
    <div class="loader loader-inner-1">
        <div class="loader loader-inner-2">
            <div class="loader loader-inner-3">
            </div>
        </div>
    </div>
</div>
<!--Preloader ends-->
