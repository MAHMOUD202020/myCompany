
<!-- Footer Section Start -->
<footer class="footer-wrap">
    <div class="footer-top">
        <div class="container">
            <div class="row pt-100 pb-75">
                <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12">
                    <div class="footer-widget">
                        <a href="index.html" class="footer-logo">
                            <img style="max-width: 100px;" src="{{asset('assets/web/images/logo.png')}}" alt="Image">
                        </a>
                        <p class="comp-desc">
                            Excape Egypt: هي وكالة مبادرة التسويق الداخلي في مصر تهدف إلى تغيير الطريقة التي يقوم بها المصريون بالتسويق ورفع مفهومهم عن التسويق. لقد عملنا مع أكثر من 100 عميل في مجالات مختلفة ...                        </p>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12">
                    <div class="footer-widget">
                        <h3 class="footer-widget-title">بيانات التواصل</h3>
                        <ul class="contact-info list-style">
                            <li>
                                <i class="flaticon-map"></i>
                                <p>العنوان : طريق الحريه رقم ١٦٥</p>
                            </li>
                            <li>
                                <i class="flaticon-support"></i>
                                <a href="tel:011269000"> +966 54 633 9689</a>
                            </li>

                            <li>
                                <i class="flaticon-email"></i>
                                <a href="mailto:marketing@okclinics.com"> info@excapeegypt.com</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12 ps-xl-4">
                    <div class="footer-widget">
                        <h3 class="footer-widget-title">الخدمات</h3>
                        <ul class="footer-menu list-style">
                            @foreach(cache('services') as $service)
                                <li>
                                    <a href="#about">
                                        <i class="ri-arrow-left-s-line"></i>
                                        {{$service->name}}
                                    </a>
                                </li>
                            @endforeach
                        </ul>
                    </div>
                </div>
            </div>
            <div class="footer-bottom">
                <div class="row align-items-center">
                    <div class="col-md-6">
                        <p class="copyright-text"><i class="ri-copyright-line"></i> All Rights Reserved By <a href="" target="_blank">excape egypt</a></p>
                    </div>
                    <div class="col-md-6 text-md-end">
                        <div class="social-link">
                            <h6>Follow Us On: </h6>
                            @include('web.layouts.social-links')
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- Footer Section End -->
