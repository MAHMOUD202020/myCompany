@php($routeName = request()->route()->getName())

@php($page = isset($page) ? $page : 'page')
<!-- Header Section Start -->
<header class="header-wrap {{$page == 'home' ? 'style5' : 'style4'}}">
    @if($page != 'home')
    <div class="container mb">
        <div class="header-top">
            <div class="row align-items-center">
                <div class="col-lg-8 col-md-7">
                    <div class="header-top-left">
                        <ul class="contact-info list-style">
                            <li><i class="flaticon-phone-call"></i> <a href="tel:0596920000">0596920000</a></li>
                            <li><i class="flaticon-time"></i><p>السبت - الخميس: 10:00 ص - 7:00 م</p></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4 col-md-5">
                    <div class="header-top-right">
                        @include('web.layouts.social-links')
                    </div>
                </div>
            </div>
        </div>
    </div>
    @endif

    <div class="container">
        <div class="header-bottom">
            <nav class="navbar navbar-expand-lg navbar-light header-sticky">
                <a class="navbar-brand" >
                    <img style="max-height: 50px" class="logo-light" src="{{asset( $page != 'home' ? 'assets/web/images/logo2.jpg' : 'assets/web/images/logo.png')}}" alt="Image">
                    <img style="max-height: 50px" class="logo-dark" src="{{asset( $page != 'home' ? 'assets/web/images/logo2.jpg' : 'assets/web/images/logo.png')}}" alt="Image">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav mx-auto">
                        <li class="nav-item"><a class="nav-link {{$routeName == 'web.home' ? 'active' : ''}}" href="/">الرئيسيه</a></li>
                        <li class="nav-item"><a class="nav-link {{$routeName == 'web.aboutUs' ? 'active' : ''}}" href="{{route('web.aboutUs')}}">من نحن</a></li>
                        <li class="nav-item"><a class="nav-link {{$routeName == 'web.services' ? 'active' : ''}}" href="{{route('web.services')}}">خدماتنا</a></li>
                        <li class="nav-item"><a class="nav-link {{$routeName == 'web.projects' ? 'active' : ''}}" href="{{route('web.projects')}}">معرض الاعمال</a></li>
                        <li class="nav-item"><a class="nav-link {{$routeName == 'web.contactUs' ? 'active' : ''}}" href="{{route('web.contactUs')}}">تواصل معنا</a></li>
                    </ul>
                </div>
                <div class="other-option md-none">
                    <a href="#contact" class="btn style1">تواصل معنا الآن</a>
                </div>
            </nav>
        </div>
    </div>
</header>
<!-- Header Section End -->
