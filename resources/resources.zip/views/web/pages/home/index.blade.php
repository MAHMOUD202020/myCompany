@extends('web.master')

@section('content')

    @include('web.pages.home.hero')

    @include('web.pages.home.services')

    @include('web.pages.home.projects')

    @include('web.pages.home.features')

    @include('web.pages.home.testimonial')

    @include('web.pages.home.partner')

    @include('web.pages.home.contact')



@endsection

@section('js')

    <script>
        $(function () {

            // $x = new TypeIt('#textContainer',{
            //     strings: ["جلدية", "ليزر", "جراحات تجميلية.",],
            //     typeSpeed: 500,
            //     cursorChar:"",
            //     breakLines: false,
            //     loop:true,
            // }).go();

        })
    </script>
@endsection
