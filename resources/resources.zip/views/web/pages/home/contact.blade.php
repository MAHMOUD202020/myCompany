
<!-- Contact Section Start -->
<section id="contact" class="contact-wrap style4  pt-100 pb-50">
    <div class="container">
        <div class="row">
            <div class="col-xl-6 offset-xl-3 col-lg-8 offset-lg-2">
                <div class="section-title style1 text-center mb-40">
                    <span>ارسال طلب للتواصل</span>
                    <h2>تواصل معنا الآن</h2>
                </div>
            </div>
        </div>
        <div class="row gx-5 align-items-center">
            <div class="col-lg-6">
                <h4>
                    اكسيب ايجيبت هنا لبناء وتنمية وجودك الرقمي, نود التواصل معك حتي نتمكن
من مساعدتك.
                </h4>

                <div>
                    <h5 class="border-bottom border-solid mt-3">
                        مكتب الرياض
                    </h5>
                    <p>
                        العنوان: طريق الحريه رقم ١٦٥
                    </p>
                    <p>
                        البريد الإلكتروني: <a href="mailto:info@excapeegypt.com">info@excapeegypt.com</a>
                    </p>
                    <p>
                        رقم التليفون: <a href="tel:+966 54 633 9689">+966 54 633 9689</a>
                    </p>
                    <p>
                        مواعيد العمل: الأحد-الخميس 05:00- 09:00
                    </p>
                </div>
                <div>
                    <h5 class="border-bottom border-solid mt-3">
                        مكتب القاهره
                    </h5>
                    <p>
                        العنوان: طريق الحريه رقم ١٦٥
                    </p>
                    <p>
                        البريد الإلكتروني: <a href="mailto:info@excapeegypt.com">info@excapeegypt.com</a>
                    </p>
                    <p>
                        رقم التليفون: <a href="tel:+966 54 633 9689">+966 54 633 9689</a>
                    </p>
                    <p>
                        مواعيد العمل: الأحد-الخميس 05:00- 09:00
                    </p>
                </div>
            </div>
            <div class="col-lg-6 book-appointment">
                <form class="form-wrap" id="contactForm" method="post" action="{{asset('web.sendMessage')}}">
                    <h5>تواصل معنا</h5>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="form-group">
                                <input type="text" name="name" placeholder="الاسم الكريم" id="name"
                                       required data-error="من فضلك ادخل اسمك الشخصي">
                                <div class="help-block with-errors"></div>
                            </div>
                        </div>
                        <div class="col-lg-12 ">
                            <div class="form-group">
                                <input type="text" name="phone_number" placeholder="رقم الجوال*"
                                       id="phone_number" required
                                       data-error="من فضلك قم بادخال رقم الهاتف">
                                <div class="help-block with-errors"></div>
                            </div>
                        </div>

                        <div class="col-md-12">
                            <div class="form-group">
                                <select name="subject" id="subject">
                                    @foreach($services as $service)
                                        <option>{{$service->name}}</option>
                                    @endforeach
                                </select>
                                <div class="help-block with-errors"></div>
                            </div>
                        </div>

                        <div class="col-md-12">
                            <button type="submit" class="btn style2">ارسال الطلب</button>
                            <div id="msgSubmit" class="h3 text-center hidden"></div>
                            <div class="clearfix"></div>

                            <div class="mt-5">
                                @include('web.layouts.social-links')
                            </div>
                        </div>
                    </div>
                </form>

            </div>
        </div>
    </div>

</section>
<!-- Contact Section End -->


