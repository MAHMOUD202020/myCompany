<section id="service" class="service-wrap pt-100 pb-75">
    <div class="container">
        <div class="row">
            <div class="col-xl-6 offset-xl-3 col-lg-8 offset-lg-2">
                <div class="section-title style3 text-center mb-40">
                    <h2>نحن شركائك في النمو والابتكار الرقمي</h2>
                    <span>تساعدك خدماتنا الرقمية الشاملة
                        على بناء عملك</span>
                </div>
            </div>
        </div>
        <div class="row justify-content-center">
            @foreach(cache('services') as $service)
                <div class="col-xl-4 col-lg-6 col-md-6 aos-init" data-aos="fade-right" data-aos-duration="1200" data-aos-delay="500">
                    <div class="service-card style1">
                        <div class="service-img">
                            <img  class="loading-lazy-1"  src="{{asset('assets/web/images/loading.png')}}" data-src="{{asset("assets/web/images/services/$service->img")}}" alt="Image">
                        </div>
                        <div class="service-info">
                            <span class="service-icon"><i class="flaticon-check"></i></span>
                            <h3><a href="{{route('web.services.show', $service->id)}}">{{$service->name}}</a></h3>
                            <p>{{$service->shortDescription}}</p>
                            <a href="{{route('web.services.show', $service->name_en)}}" class="btn btn-primary mt-2">إقرء المزيد</a>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</section>
