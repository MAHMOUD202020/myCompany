<!-- Testimonial Section Start -->
<section class="testimonial-wrap ptb-100 bg-albastor" id="testimonial">
    <div class="container">
        <div class="row">
            <div class="col-xl-6 offset-xl-3 col-lg-8 offset-lg-2">
                <div class="section-title style4 text-center mb-40">
                    <h2>اراء عملاء Excape Egypt</h2>
                    <span>اراء عملائنا بناء علي التجربة التي خاضوها معنا</span>
                </div>
            </div>
        </div>
        <div class="testimonial-slider-three owl-carousel">
            <div class="testimonial-card style4">
                <div class="client-img">
                    <span class="quote-icon">
                                    <i class="flaticon-quote-1"></i>
                                </span>
                </div>
                <div class="client-info-wrap">
                    <p class="client-quote">“شركة تسويق وبرمجة Excape Egypt رائعة! تقديمهم للخدمات يتجاوز التوقعات. أنا ممتن لفريقهم المحترف والمبدع الذي ساعدني في تحقيق نجاح مشروعي. لديهم خبرة عالية وفهم عميق لاحتياجات السوق. أنصح بشدة بالتعامل معهم! ”</p>
                    <div class="client-info">
                        <h3>نورة الشمري</h3>
                    </div>
                </div>
            </div>
            <div class="testimonial-card style4">
                <div class="client-img">
                    <span class="quote-icon">
                        <i class="flaticon-quote-1"></i>
                    </span>
                </div>
                <p class="client-quote">“فريق العمل كان متعاونًا ومتفانيًا في تقديم الخدمات. كانوا يسمعون بعناية لمتطلباتي ويوفرون حلولًا مبتكرة وفعالة. لقد ساعدوني في تعزيز حضور عملي على الإنترنت وتحقيق نمو ملحوظ في العملاء. أنا سعيد جدًا بالنتائج وأنصح بشدة بالتعامل معهم ”</p>
                <div class="client-info-wrap">
                    <div class="client-info">
                        <h3>عبدالرحمن الجابري
                        </h3>
                    </div>
                </div>
            </div>
            <div class="testimonial-card style4">
                <div class="client-img">
                    <span class="quote-icon">
                        <i class="flaticon-quote-1"></i>
                    </span>
                </div>
                <p class="client-quote">“Excape Egypt هي شركة محترفة وموثوقة في مجال التسويق والبرمجة. كانت تجربتي معهم ممتازة بشكل عام. كان فريق العمل متعاونًا ومتفهمًا لاحتياجاتي.  أنا سعيد جدًا بالنتائج التي حققتها بفضل جهودهم الدؤوبة. أوصي بشدة بفريق Excape Egypt”</p>
                <div class="client-info-wrap">
                    <div class="client-info">
                        <h3>أحمد الصقري</h3>
                    </div>
                </div>
            </div>
            <div class="testimonial-card style4">
                <div class="client-img">
                    <span class="quote-icon">
                                    <i class="flaticon-quote-1"></i>
                                </span>
                </div>
                <p class="client-quote">“شكرًا لشركة Excape Egypt على خدماتهم الممتازة في مجال التسويق والبرمجة.  الفريق محترفًا للغاية وداعمًا، واستجابوا بسرعة لجميع استفساراتي ومطالبي. أوصي بشدة بفريق Excape Egypt لأي شخص يبحث عن حلول تسويقية فعالة ومبتكرة.”</p>
                <div class="client-info-wrap">
                    <div class="client-info">
                        <h3>ليلى السلماني</h3>
                    </div>
                </div>
            </div>
            <div class="testimonial-card style4">
                <div class="client-img">
                    <div class="quote-icon">
                        <i class="flaticon-quote-1"></i>
                    </div>
                </div>
                <p class="client-quote">“لقد كانت تجربتي معهم مذهلة قدموا لي استراتيجيات تسويقية مبتكرة وقاموا بتنفيذها ببراعة. رأيت زيادة ملحوظة في حركة المرور والمبيعات بفضل جهودهم. أنا سعيد جدًا بالنتائج استراتيجياتهم الذكية. أنا ممتن للغاية للعمل مع Excape Egypt وأوصي بهم بشدة ”</p>
                <div class="client-info-wrap">
                    <div class="client-info">
                        <h3>رامي احمد</h3>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Testimonial Section End -->
