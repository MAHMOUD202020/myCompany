<!-- Team Section Start -->
<section id="team" class="team-wrap pb-100 pt-100">
    <div class="container">
        <div class="row">
            <div class="col-xl-6 offset-xl-3 col-lg-8 offset-lg-2">
                <div class="section-title style1 text-center mb-40">
                    <span>فريق عمل متميز</span>
                    <h2>تعرف على اطباؤنا</h2>
                </div>
            </div>
        </div>

        @php($teams = [
    ['name' => 'د.عبد الله العجلان', 'job' => 'استشاري تقويم الاسنان'],
    ['name' => 'د.عبد الله الأسمري', 'job' => 'استشاري الجلدية والتجميل'],
    ['name' => 'د.سارة المحفوظ', 'job' => 'استشارية تقويم الاسنان'],
    ['name' => 'د.محمد القرني', 'job' => 'استشاري زراعة وتجميل الأسنان'],
    ['name' => 'د.بيشي القرني', 'job' => 'استشاري جراحة وتجميل الوجه والفكين وزراعة الاسنان'],
    ['name' => 'د.منصور المالك', 'job' => 'استشاري الاسنان الصناعية'],
    ['name' => 'د.محمد الشثري', 'job' => 'استشاري تركيبات الآنسان'],
    ['name' => 'د.محمد التميمي', 'job' => 'جراحة الوجه والفكين وزراعة الاسنان'],
    ['name' => 'د.صقر', 'job' => 'استشاري زراعة الاسنان ومعالجة اللثة'],
    ['name' => 'د.عبد الله القرني', 'job' => 'طبيب أسنان'],
    ['name' => 'د.دعاء نور الدين', 'job' => 'اخصائية الجلدية والتجميل والليزر'],
    ['name' => 'د.خالد مهاجر', 'job' => 'استشاري الامراض الجلدية والتجميل'],
    ['name' => 'د.محمد المبارك', 'job' => 'استشاري الامراض الجلدية والتجميل'],
    ['name' => 'د.عمرو عبد الجبار', 'job' => 'استشاري الجلدية والتجميل'],
    ['name' => 'د.صالح الشاطري', 'job' => 'استشاري الجلدية والتجميل'],
])

        <div class="team-slider-two owl-carousel">
           @foreach($teams as $key => $team)
                <div class="team-card style5">
                    <div class="team-img" style="max-height: 243px; overflow: hidden">
                        <img class="loading-lazy-3"  src="{{asset('assets/web/images/loading.png')}}"  data-src="{{asset("assets/web/images/team/". $key+1 .".jpg")}}" alt="أوكي كلينك">
                    </div>
                    <div class="team-info">
                        <h3>{{$team['name']}}</h3>
                        <span>{{$team['job']}}</span>
                    </div>
                </div>
           @endforeach
        </div>
    </div>
</section>
<!-- Team Section End -->
