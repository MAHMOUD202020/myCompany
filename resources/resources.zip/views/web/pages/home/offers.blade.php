@php($offers = cache('offersCache'))
@if($offers)
    <!-- Service Section Start -->
    <section id="offers" class="offers-wrap pb-100">
        <div class="container">
            <div class="row">
                <div class="col-xl-6 offset-xl-3 col-lg-8 offset-lg-2">
                    <div class="section-title style3 text-center mb-40">
                        <span>عروض</span>
                        <h2>لا تفوت عروض أوكي كلينك</h2>
                    </div>
                </div>
            </div>

            <div class="service-slider-four owl-carousel ">
                @foreach($offers as $offer)
                    <div class="service-card style7">
                        <a href="">

                        </a>
                        <img class="loading-lazy-2"  src="{{asset('assets/web/images/loading.png')}}" data-src="{{asset("assets/web/images/offers/$offer->img")}}" alt="Image">
                        <div class="service-info">
                            <h3><a href="{{$offer->shortDescription}}">{{$offer->name}} <img style="width: 25px; display: inline-block" src="{{asset('assets/web/images/link.png')}}"></a></h3>
                            <p class="mt-2">
                                @if($offer->end_price)
                                    @if($offer->price)
                                        <strike class="text-white font-weight-bold ml-2">{{$offer->price}} ريال </strike>
                                    @endif
                                    &nbsp;&nbsp;
                                    <span class="text-white font-weight-bold">{{$offer->end_price}} ريال </span>
                                @endif
                            </p>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </section>
    <!-- Service Section End -->

@endif
