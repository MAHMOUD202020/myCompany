
<!-- Gallery Section Start -->
<section id="gallery" class="gallery-wrap pb-100">
    <div class="container">
        <div class="row">
            <div class="col-xl-6 offset-xl-3 col-lg-8 offset-lg-2">
                <div class="section-title style3 text-center mb-40">
                    <span>عينات مرئية لتفوقنا الطبي</span>
                    <h2>معرض الصور في مركزنا الطبي</h2>
                </div>
            </div>
        </div>

        @php($folderPath = glob( public_path('assets/web/images/gallery/') ))
        @php($images = \Illuminate\Support\Facades\File::files($folderPath))

        <div class="gallery-item-wrap style7">

            @foreach( $images as $image )
                <div class="gallery-card style5">
                    <img class="loading-lazy-4" src="{{asset('assets/web/images/loading.png')}}" data-src="{{asset('assets/web/images/gallery/'.$image->getFilename())}}" alt="Image" >
                </div>
            @endforeach
        </div>
    </div>
</section>
<!-- Gallery Section End -->
