@php($folderPath = glob( public_path('assets/web/images/partners') ))
@php($images = \Illuminate\Support\Facades\File::files($folderPath))

<!-- Partner wrap  Start -->
<div class="partner-wrap pb-100  pt-100">
    <div class="container">
        <div class="row">
            <div class="col-xl-6 offset-xl-3 col-lg-8 offset-lg-2">
                <div class="section-title style4 text-center mb-40">
                    <h2>شركاء النجاح</h2>
                    <span>فخورين أننا كنا شركاء بصناعة جزء من نجاح شركائنا
ونحن فخورون بالمساهمة في نجاحهم.</span>
                </div>
            </div>
        </div>
        <div class="partner-slider owl-carousel">

            @foreach($images as $image)
                <div class="partner-item style2">
                    <img  class="loading-lazy-3" style="max-height: 120px"  src="{{asset('assets/web/images/loading.png')}}" data-src="{{asset("assets/web/images/partners/".$image->getFilename())}}" alt="Image">
                </div>
            @endforeach
        </div>
    </div>
</div>
<!-- Partner wrap End -->
