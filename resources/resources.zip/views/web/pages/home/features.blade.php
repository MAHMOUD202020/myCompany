<section id="service" class="service-wrap pt-100 pb-75">
    <div class="container">
        <div class="row">
            <div class="col-xl-6 offset-xl-3 col-lg-8 offset-lg-2">
                <div class="section-title style3 text-center mb-40">
                    <span>ما يميزنا</span>
                    <h2>لماذا يجب عليك اختيارنا</h2>
                </div>
            </div>
        </div>
        <div class="row justify-content-center">

            <div class="col-xl-4 col-lg-6 col-md-6 aos-init" data-aos="fade-right" data-aos-duration="1200" data-aos-delay="500">
                <div class="service-card style6">
                    <div class="service-info-wrap">
                        <div class="service-icon">
                            <i class="flaticon-quality-control"></i>
                        </div>
                        <div class="service-info">
                            <h3>خبرة ممتدة</h3>
                            <p>نتمتع بخبرة واسعة في مجال التسويق والبرمجة، حيث قمنا بتقديم خدماتنا لعدد كبير من العملاء في مختلف الصناعات والقطاعات</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-lg-6 col-md-6 aos-init" data-aos="fade-right" data-aos-duration="1200" data-aos-delay="200">
                <div class="service-card style6">
                    <div class="service-info-wrap">
                        <div class="service-icon">
                            <i class="flaticon-customer"></i>
                        </div>
                        <div class="service-info">
                            <h3>استراتيجيات فعالة</h3>
                            <p>نحن ملتزمون بتحقيق أهداف عملائنا وزيادة رؤيتهم ونجاحهم في السوق. ونقوم بتطوير استراتيجيات تسويقية مبتكرة ومتكاملة لاستهداف الجمهور المناسب </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-lg-6 col-md-6 aos-init" data-aos="fade-right" data-aos-duration="1200" data-aos-delay="300">
                <div class="service-card style6">
                    <div class="service-info-wrap">
                        <div class="service-icon">
                            <i class="flaticon-support"></i>
                        </div>
                        <div class="service-info">
                            <h3>تواصل وتعاون فعّال</h3>
                            <p>نحن نولي اهتمامًا كبيرًا لتواصل فعّال مع عملائنا. نحن نستمع إلى احتياجاتكم وأهدافكم ونعمل بشكل وثيق معكم لتحقيقها</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
