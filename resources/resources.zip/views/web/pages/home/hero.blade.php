
<!-- Hero Section Start -->
<section id="hero" class="hero-wrap style5  bg-f" style="background-image: url('{{asset('assets/web/images/home/background-image.png')}}')">
    <div class="overlay op-9 bg-prussian"></div>
    <div class="container">
        <div class="row gx-5 align-items-center">
            <div class="col-lg-6 order-1 order-lg-0">
                <div class="hero-content" data-speed="0.10" data-revert="true">
                    <h1>ماذا لو كان
                        إتحاد فريقنا من
                        أجل ازدهار عملك ؟</h1>
                    <div class="hero-btn">
                        <a href="#gallery" class="btn style2">شاهد اعمالنا</a>
                        <a href="#contact" class="btn style2">اتحد معنا</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 order-0 order-lg-1">
                <div class="hero-img-wrap">
                    <div class="hero-img-one bounce">
                        <img src="{{asset('assets/web/images/home/v1.png')}}" alt="Image">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Hero Section End -->


