<!-- About Section Start -->
<section id="about" class="about-wrap style4 pt-100">
    <div class="container">
        <div class="row gx-5 align-items-center">
            <div class="col-lg-6">
                <div class="about-img-wrap" >
                    <img  class="loading-lazy-1" src="{{asset('assets/web/images/loading.png')}}" data-src="{{asset('assets/web/img/about/about-img-6.jpg')}}" alt="Image">
                </div>
            </div>
            <div class="col-lg-6">
                <div class="about-content">
                    <div class="content-title style4">
                        <span>لماذا نحن</span>
                        <h2>لماذا يجب عليك اختيارنا</h2>
                        <p class="h5">
                            فريقنا المتميز المكون من أفضل الأطباء الأستشاريين السعوديين المتمتعين بمسوى عال جدا من الخبرة بتسخير كل مجهودهم وامكانيات اوكي كلينك  لتقديم أفضل الخدمات الطبية بمختلف الأقسام

                        </p>
                    </div>

                    <div class="tab-content about-tab-content">
                        <div class="tab-pane fade show active" id="tab_10" role="tabpanel">
                            <div class="row gx-4 align-items-center">
                                <div class="col-md-6">
                                    <div class="about-img">
                                        <img class="loading-lazy-1" src="{{asset('assets/web/images/loading.png')}}" data-src="{{asset('assets/web/img/about/about-img-7.jpg')}}" alt="Image">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <h5>مجموعة من اهم المزايا</h5>
                                    <ul class="content-feature-list list-style style4">
                                        <li><span><i class="ri-check-double-line"></i></span>أحدث الأجهزة المعدات والتقنيات الطبية</li>
                                        <li><span><i class="ri-check-double-line"></i></span>تغطية كاملة لكافة الجراحات التجميلية</li>
                                        <li><span><i class="ri-check-double-line"></i></span> طاقم طبّي ذو خبرة وكفاءة عالية</li>
                                        <li><span><i class="ri-check-double-line"></i></span>  الإلتزام بتقديم أفضل الخدمات الطبيّة</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- About Section End -->
