<section id="service" class="service-wrap pt-100 pb-75">
    <div class="container">
        <div class="row">
            <div class="col-xl-6 offset-xl-3 col-lg-8 offset-lg-2">
                <div class="section-title style3 text-center mb-40">
                    <span>خدماتنا</span>
                    <h2>نحن نقدم أفضل الخدمات لعملائنا</h2>
                </div>
            </div>
        </div>
        <div class="row justify-content-center">

            <div class="col-xl-4 col-lg-6 col-md-6 aos-init" data-aos="fade-right" data-aos-duration="1200" data-aos-delay="500">
                <div class="service-card style6">
                    <div class="service-info-wrap">
                        <div class="service-icon">
                            <i class="flaticon-face"></i>
                        </div>
                        <div class="service-info">
                            <h3>إزالة دهون الخد</h3>
                            <p>تقنية مبتكرة لنحت الخدود وتجميل ملامح الوجه بشكل طبيعي وفعال</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-4 col-lg-6 col-md-6 aos-init" data-aos="fade-right" data-aos-duration="1200" data-aos-delay="200">
                <div class="service-card style6">
                    <div class="service-info-wrap">
                        <div class="service-icon">
                            <i class="flaticon-skin-care"></i>
                        </div>
                        <div class="service-info">
                            <h3>الثيرا لشد البشرة</h3>
                            <p>علاج غير جراحي يستخدم تقنية الثيرا لشد وتحسين مرونة البشرة واستعادة شبابها.</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-lg-6 col-md-6 aos-init" data-aos="fade-right" data-aos-duration="1200" data-aos-delay="300">
                <div class="service-card style6">
                    <div class="service-info-wrap">
                        <div class="service-icon">
                            <i class="flaticon-dental-care-1"></i>
                        </div>
                        <div class="service-info">
                            <h3>رعاية الأسنان</h3>
                            <p>رعاية شاملة لصحة الأسنان مثل التنظيف الدوري، الحشوات، العلاجات اللثوية وغيرها.</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-lg-6 col-md-6 aos-init" data-aos="fade-right" data-aos-duration="1200" data-aos-delay="400">
                <div class="service-card style6">
                    <div class="service-info-wrap">
                        <div class="service-icon">
                            <i class="flaticon-rhinoplasty"></i>
                        </div>
                        <div class="service-info">
                            <h3>تعديل الأنف جراحيًا</h3>
                            <p>إجراء جراحي لتصحيح شكل الأنف وتحسين التوازن الجمالي للوجه.</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-4 col-lg-6 col-md-6 aos-init" data-aos="fade-right" data-aos-duration="1200" data-aos-delay="600">
                <div class="service-card style6">
                    <div class="service-info-wrap">
                        <div class="service-icon">
                            <i class="flaticon-laser-1"></i>
                        </div>
                        <div class="service-info">
                            <h3>ليزر إزالة الشعر</h3>
                            <p>تقنية الليزر لإزالة الشعر طويلة الأمد والفعالة على مختلف مناطق الجسم.</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-lg-6 col-md-6 aos-init" data-aos="fade-right" data-aos-duration="1200" data-aos-delay="700">
                <div class="service-card style6">
                    <div class="service-info-wrap">
                        <div class="service-icon">
                            <i class="flaticon-laser-3"></i>                        </div>
                        <div class="service-info">
                            <h3>تعديل الأذن جراحيًا</h3>
                            <p>جراحة تصحيح الأذن لتحسين شكلها وتعديل العيوب الشكلية للأذن.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
