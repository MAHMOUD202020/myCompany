

<!-- Hero Section Start -->
<section id="hero" class="hero-wrap bg-f hero-bg-14 style4" style="background-image: url('{{asset('assets/web/images/cover.jpg')}}')">
    <div class="container">
        <div class="row gx-5 align-items-end">
            <div class="col-lg-6">
                <div class="hero-content">
                    <h1 data-aos="fade-up" data-aos-duration="1200" data-aos-delay="300" class="text-white">اوكي كلينك</h1>
                    <h4 id="subTitle" data-aos="fade-up" data-aos-duration="1200" data-aos-delay="400" class="text-white" >
                        افضل واضخم مجمع عيادات   <span style="line-height: 0!important;" id="textContainer" class="example4 font-weight-bold text-white d-inline-block">أسنان</span> بالرياض

                    </h4>
                    <div class="hero-btn" data-aos="fade-up" data-aos-duration="1200" data-aos-delay="500">
                        <a id="btnHeaderContact" href="#contact" class="btn style2">تواصل معنا الآن</a>
                        <a id="btnHeaderWhatsapp" href="https://api.whatsapp.com/send/?phone=966596920000" class="btn style2 bg-success " style="margin-right: 5px">
                            <img  style="width: 15px; display: inline-block; margin-left: 10px" src="{{asset('assets/web/images/whatsapp-svgrepo-com.svg')}}">
                            تواصل عبر الواتساب
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="hero-img-wrap">
{{--                    <img src="{{asset('assets/web/images/cover.png')}}" style="max-height: 500px" alt="Image">--}}
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Hero Section End -->
<h1></h1>
<p></p>
