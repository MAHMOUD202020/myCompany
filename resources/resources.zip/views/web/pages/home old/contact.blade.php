
<!-- Contact Section Start -->
<section id="contact" class="contact-wrap style4  pt-100 pb-50">
    <div class="container">
        <div class="row">
            <div class="col-xl-6 offset-xl-3 col-lg-8 offset-lg-2">
                <div class="section-title style1 text-center mb-40">
                    <span>ارسال طلب للتواصل</span>
                    <h2>تواصل معنا الآن</h2>
                </div>
            </div>
        </div>
        <div class="row gx-5 align-items-center">
            <div class="col-lg-6">
                <div  class="contact-bg-one bg-f loading-lazy-bg" data-src="{{asset('assets/web/images/contact.jpg')}}" style=" background-image: url('{{'assets/web/images/loading.png'}}'); max-height: 420px">
                </div>
            </div>
            <div class="col-lg-6 book-appointment">
                <form class="form-wrap" id="contactForm" method="post" action="{{asset('web.sendMessage')}}">
                    <h5>تواصل معنا</h5>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="form-group">
                                <input type="text" name="name" placeholder="الاسم الكريم" id="name"
                                       required data-error="من فضلك ادخل اسمك الشخصي">
                                <div class="help-block with-errors"></div>
                            </div>
                        </div>
                        <div class="col-lg-12 ">
                            <div class="form-group">
                                <input type="text" name="phone_number" placeholder="رقم الجوال*"
                                       id="phone_number" required
                                       data-error="من فضلك قم بادخال رقم الهاتف">
                                <div class="help-block with-errors"></div>
                            </div>
                        </div>

                        <div class="col-md-12">
                            <div class="form-group">
                                <select name="subject" id="subject">
                                    <option>قسم الجلدية</option>
                                    <option>قسم الاسنان</option>
                                    <option>جراحة التجميل</option>
                                    <option>الليزر والبشرة</option>
                                    <option>الجراحة النسائية</option>
                                    <option>جراحة الاوعية الدموية</option>
                                </select>
                                <div class="help-block with-errors"></div>
                            </div>
                        </div>

                        <div class="col-md-12">
                            <button type="submit" class="btn style2">ارسال الطلب</button>
                            <div id="msgSubmit" class="h3 text-center hidden"></div>
                            <div class="clearfix"></div>

                            <div class="mt-5">
                                <ul class="social-profile list-style style1">
                                    <li>
                                        <a target="_blank" href="https://www.facebook.com/OkClinic">
                                            <i class="ri-facebook-line"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a target="_blank" href="https://twitter.com/Okclinics">
                                            <i class="ri-twitter-line"></i>
                                        </a>
                                    </li>
                                    <li id="call">
                                        <a target="_blank" href="https://www.instagram.com/okclinics/">
                                            <i class="ri-instagram-line"></i>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </form>

            </div>
        </div>
    </div>


    <hr >

    <div >

        <div class="row  m-auto">
            <div class="col-md-4 pt-5 pb-5 text-center bg-light font-weight-bold" style="border: 1px solid #e9ecef">العنوان : اوكي كلينك - حي الربيع أمام مدارس المملكة 13315</div>
            <div class="col-md-4 pt-5 pb-5 text-center bg-light font-weight-bold" style="border: 1px solid #e9ecef">رقم التواصل : 011269000 - 0596920000</div>
            <div class="col-md-4 pt-5 pb-5 text-center bg-light font-weight-bold" style="border: 1px solid #e9ecef">البريد الألكتروني : marketing@okclinics.com</div>
        </div>
        <div class="contact-map">
            <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3622.206680498096!2d46.661018484998586!3d24.788375384087995!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e2ee3acb0830bd3%3A0x1f1eaf1c58a1a5ad!2zT2sgQ2xpbmljIHwg2KfZiNmD2Yog2YPZhNmK2YbZgw!5e0!3m2!1sar!2seg!4v1687299712802!5m2!1sar!2seg"  style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>        </div>
    </div>

</section>
<!-- Contact Section End -->


