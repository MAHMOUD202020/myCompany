@extends('web.master')

@section('content')

    @include('web.pages.home.slider')

    @include('web.pages.home.whyUs')

    @include('web.pages.home.services')

    @include('web.pages.home.contact')

    @include('web.pages.home.offers')

    @include('web.pages.home.testimonial')

    @include('web.pages.home.team')

    @include('web.pages.home.gallery')

@endsection

@section('js')

    <script>
        setTimeout(function () {
            $('.js-preloader').hide(250);
        }, 500)

        $(function () {

            $x = new TypeIt('#textContainer',{
                strings: ["جلدية", "ليزر", "جراحات تجميلية.",],
                typeSpeed: 500,
                cursorChar:"",
                breakLines: false,
                loop:true,
            }).go();

            $('.loading-lazy-1').each(function(){
                $(this).attr('src', $(this).attr('data-src'));
            })

            $('.loading-lazy-bg').each(function(){
                $(this).css('background-image', 'url(' + $(this).attr('data-src') + ')');
            })

            $('.loading-lazy-2').each(function(){
                $(this).attr('src', $(this).attr('data-src'));
            })

            $('.loading-lazy-3').each(function(){
                $(this).attr('src', $(this).attr('data-src'));
            })


            setTimeout(function(){
                $('.loading-lazy-4').each(function(){
                    $(this).attr('src', $(this).attr('data-src'));
                })
            }, 1000)

            $('#contactForm').on('submit', function (e) {

                e.preventDefault();

                if($('.help-block').text().length == 0){

                    form = this;

                    $.ajax({
                        headers: {
                            'X-CSRF-TOKEN': '{{csrf_token()}}'
                        },
                        method:'POST',
                        url: '{{route('web.sendMessage')}}',
                        data:$(this).serialize(),

                        success($xhr){
                            location.href = '/sendMessage/success/'+$xhr
                        },

                        error($xhr){
                            alert($xhr.responseJSON.message)
                        }
                    })
                }

            })
        })
    </script>
@endsection
