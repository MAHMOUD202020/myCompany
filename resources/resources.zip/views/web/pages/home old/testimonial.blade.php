<!-- Testimonial Section Start -->
<section class="testimonial-wrap ptb-100 bg-albastor" id="testimonial">
    <div class="container">
        <div class="row">
            <div class="col-xl-6 offset-xl-3 col-lg-8 offset-lg-2">
                <div class="section-title style4 text-center mb-40">
                    <span>اراء عملائنا</span>
                    <h2>اراء عملاء أوكي كلينك</h2>
                </div>
            </div>
        </div>
        <div class="testimonial-slider-three owl-carousel">
            <div class="testimonial-card style4">
                <div class="client-img">
                    <span class="quote-icon">
                                    <i class="flaticon-quote-1"></i>
                                </span>
                </div>
                <div class="client-info-wrap">
                    <p class="client-quote">“د استخدمت خدمة إزالة الشعر بالليزر في أوكي كلينك وأنا راضٍ جدًا. كان العلاج فعالًا والأطباء كانوا محترفين ولطفاء. أنصح بهذا المركز بشدة”</p>
                    <div class="client-info">
                        <h3>نورة الشمري</h3>
                    </div>
                </div>
            </div>
            <div class="testimonial-card style4">
                <div class="client-img">
                    <span class="quote-icon">
                        <i class="flaticon-quote-1"></i>
                    </span>
                </div>
                <p class="client-quote">“تجربتي في أوكي كلينك كانت مذهلة. فريق العمل كان محترفًا وودودًا، وتلقيت رعاية طبية عالية الجودة. أنا راضٍ جدًا عن النتائج ”</p>
                <div class="client-info-wrap">
                    <div class="client-info">
                        <h3>عبدالرحمن الجابري
                        </h3>
                    </div>
                </div>
            </div>
            <div class="testimonial-card style4">
                <div class="client-img">
                    <span class="quote-icon">
                        <i class="flaticon-quote-1"></i>
                    </span>
                </div>
                <p class="client-quote">“أوصي بشدة أوكي كلينك. استقبال رائع، وتجهيزات حديثة، وأطباء متخصصون. حققوا توقعاتي بشكل كامل وأعطوني ثقة في رعايتهم”</p>
                <div class="client-info-wrap">
                    <div class="client-info">
                        <h3>أحمد الصقري</h3>
                    </div>
                </div>
            </div>
            <div class="testimonial-card style4">
                <div class="client-img">
                    <span class="quote-icon">
                                    <i class="flaticon-quote-1"></i>
                                </span>
                </div>
                <p class="client-quote">“لقد حصلت على تقويم الأسنان في أوكي كلينك، والنتائج كانت مذهلة. الأطباء كانوا محترفين وملتزمين، والخدمة العامة كانت رائعة.”</p>
                <div class="client-info-wrap">
                    <div class="client-info">
                        <h3>ليلى السلماني</h3>
                    </div>
                </div>
            </div>
            <div class="testimonial-card style4">
                <div class="client-img">
                    <div class="quote-icon">
                        <i class="flaticon-quote-1"></i>
                    </div>
                </div>
                <p class="client-quote">“شكرًا للفريق الطبي في أوكي كلينك على تعديل الأذن جراحيًا بشكل ممتاز. كانت تجربة مريحة والنتائج رائعة. أنا سعيد وممتن للفريق على ما قدموه”</p>
                <div class="client-info-wrap">
                    <div class="client-info">
                        <h3>Will Smith</h3>
                        <span>Enterpreneur</span>
                    </div>
                </div>
            </div>
            <div class="testimonial-card style4">
                <div class="client-img">
                    <div class="quote-icon">
                        <i class="flaticon-quote-1"></i>
                    </div>
                </div>
                <p class="client-quote">“لقد تلقيت علاج الثيرا لشد البشرة في أوكي كلينك وأنا مسرورة بالنتائج. تحسنت ملمس بشرتي وظهرت عليها تجدد وشباب.”</p>
                <div class="client-info-wrap">
                    <div class="client-info">
                        <h3>Will Smith</h3>
                        <span>Enterpreneur</span>
                    </div>
                </div>
            </div>
            <div class="testimonial-card style4">
                <div class="client-img">
                    <div class="quote-icon">
                        <i class="flaticon-quote-1"></i>
                    </div>
                </div>
                <p class="client-quote">“تجربتي في مركز تبييض الأسنان في أوكي كلينك كانت ممتازة. كانت الجلسات فعالة والنتائج رائعة. أنصح بزيارة هذا المركز للحصول على ابتسامة بيضاء وجذابةالعالية.”</p>
                <div class="client-info-wrap">
                    <div class="client-info">
                        <h3>مريم الفهد
                        </h3>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Testimonial Section End -->
