@extends('web.master')

@section('content')

    @include('web.layouts.breadcrumb', ['title_page' => 'معرض الاعمال'])

    @include('web.pages.projects.projects')

    @include('web.pages.home.contact')

@endsection

@section('css')
    <style>
        #gallery .nav-link.active {
            color: #fff !important;
            background-color: #2d3d6f !important;
            border-color: #dee2e6 #dee2e6 #111d41  !important;
        }
        #gallery .nav-tabs{
            margin-right: 24px;
        }
    </style>
@endsection

@section('js')

    <script>

        let category_active = 0

        $('.category-projects').on('click', function(e){

            e.preventDefault();

            $('.category-projects .nav-link').removeClass('active');

            let children = $(this).children('.nav-link');
            let category_id = children.attr('href');

            children.addClass('active')

            if (category_active != category_id) {

                if (category_id == 0) {
                    $('.category-project').show(500)
                } else {
                    $('.category-project').show()
                    $('.category-project:not(.category-project-' + children.attr('href')).hide(500)

                }
                category_active = category_id
            }
        })
    </script>
@endsection
