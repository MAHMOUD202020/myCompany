@extends('web.master')

@section('content')

    @include('web.layouts.breadcrumb', [
    'title_page' => $project->name_ar,
     'parent_page' => ['text' => 'معرض الاعمال', 'url' => route('web.projects')],
     'bg' => asset("assets/web/images/projects/$project->cover")
     ])


    <!-- gallery Details section Start -->
    <section class="gallery-details-wrap ptb-100">
        <div class="container">
            <div class="row gx-5">
                <div class="col-xl-8">
                    <div class="gallery-desc">
                        <img src="{{asset("assets/web/images/projects/$project->img")}}" alt="Image">

                        <h2>{{$project->name_ar}}</h2>

                        {!! $project->description_ar !!}
                    </div>
                </div>
                <div class="col-xl-4">
                    @include('web.pages.projects.sidebar')
                </div>
            </div>
        </div>
    </section>
    <!-- gallery Details section End -->

@endsection

@section('js')

    <script>

    </script>
@endsection
