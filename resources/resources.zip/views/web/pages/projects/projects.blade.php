<!-- Gallery Section Start -->
<section id="gallery" class="gallery-wrap style4 pt-50 mb-100">
    <div class="container">
        <div class="row">
            <div class="col-xl-8 offset-xl-2 col-lg-10 offset-lg-1">
                <div class="section-title style1 text-center mb-40">
                    <h2> أحدث أعمالنا</h2>
                    <span>
                        أنت تعرف العمل الرائع عندما تراه تحقق من بعض المكاسب الأخيرة للعملاء.
                    </span>
                </div>
            </div>
        </div>
        <div class="row justify-content-center">
            <ul class="nav nav-tabs">
                <li class="nav-item category-projects">
                    <a class="nav-link active " href="0">الكل</a>
                </li>
                @foreach(cache('projects')->map->category->pluck('name', 'id') as $id => $category)
                    <li class="nav-item category-projects">
                        <a class="nav-link " href="{{$id}}">{{$category}}</a>
                    </li>
                @endforeach
            </ul>
            @foreach(cache('projects') as $project)
                <div class="col-lg-4 col-md-6 category-project category-project-{{$project->category->id}}">
                    <div class="gallery-card style2">
                        <a href="{{route('web.projects.show' , $project->id)}}">
                            <div class="gallery-img">
                                <img  class="loading-lazy-1" src="{{asset('assets/web/images/loading.png')}}" data-src="{{asset("assets/web/images/projects/$project->img")}}" alt="Image">
                                <div class="gallery-info" style="bottom: 30px">
                                    <a class="gallery-icon" href="{{route('web.projects.show' , $project->id)}}"><i class="ri-add-line"></i></a>
                                    <h3>
                                        <a href="{{route('web.projects.show' , $project->name_en)}}">
                                            {{$project->name}}
                                        </a>
                                    </h3>
                                    <span>
                                    {{$project->shortDescription}}
                                </span>

                                </div>
                            </div>

                        </a>
                    </div>
                </div>
            @endforeach
        </div>

        @if(cache('projects')->count() > 9)
            <div class="text-center">
                <a href="{{route('web.projects')}}" class='btn btn-primary m-auto '> عرض المزيد من سابقة الاعمال</a>
            </div>
        @endif
    </div>

</section>
<!-- Gallery Section End -->

