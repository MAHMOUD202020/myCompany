<!-- About Section Start -->
<section id="about" class="about-wrap style4 pt-50 mb-100">
    <div class="container">
        <div class="row gx-5 align-items-center">
            <div class="col-lg-6">
                <div class="about-img-wrap" >
                    <img  class="loading-lazy-1" src="{{asset('assets/web/images/loading.png')}}" data-src="{{asset('assets/web/images/about/excape-egypt.jpg')}}" alt="Image">
                </div>
            </div>
            <div class="col-lg-6">
                <div class="about-content">
                    <div class="content-title style4 mb-2">
                        <span>من نحن</span>
                        <h2>ماذا عن Excape Egypt</h2>
                        <p class="h5">
                            Excape Egypt: هي وكالة مبادرة التسويق الداخلي في مصر تهدف إلى تغيير الطريقة التي يقوم بها المصريون بالتسويق ورفع مفهومهم عن التسويق. لقد عملنا مع أكثر من 100 عميل في مجالات مختلفة ...

                        </p>
                    </div>

                    <div class="tab-content about-tab-content">
                        <div class="tab-pane fade show active" id="tab_10" role="tabpanel">
                            <div class="row gx-4 align-items-center">
                                <div class="col-md-6">
                                    <div class="about-img">
                                        <img class="loading-lazy-1" src="{{asset('assets/web/images/loading.png')}}" data-src="{{asset('assets/web/images/about/excape-egypt.2.jpg')}}" alt="Image">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <h5>الخدمات</h5>
                                    <ul class="content-feature-list list-style style4">
                                        @foreach(cache('services') as $service)
                                            <li><span><i class="ri-check-double-line"></i></span>{{$service->name}}</li>
                                        @endforeach
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- About Section End -->
