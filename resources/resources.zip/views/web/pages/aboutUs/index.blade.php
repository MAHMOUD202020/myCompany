@extends('web.master')

@section('content')

    @include('web.layouts.breadcrumb', ['title_page' => 'من نحن'])

    @include('web.pages.aboutUs.whyUs')

    @include('web.pages.home.contact')

@endsection

@section('js')

    <script>

    </script>
@endsection
