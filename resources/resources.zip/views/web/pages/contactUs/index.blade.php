@extends('web.master')

@section('content')

    @include('web.layouts.breadcrumb', ['title_page' => 'تواصل معنا'])


    @include('web.pages.home.contact')

    @include('web.pages.contactUs.contactUs')

@endsection

@section('js')

    <script>

    </script>
@endsection
