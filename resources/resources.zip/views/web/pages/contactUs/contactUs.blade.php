
<section  class="contact-wrap style4 pt-50 mb-50">
    <div >

        <div class="contact-map">
            <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3622.206680498096!2d46.661018484998586!3d24.788375384087995!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e2ee3acb0830bd3%3A0x1f1eaf1c58a1a5ad!2zT2sgQ2xpbmljIHwg2KfZiNmD2Yog2YPZhNmK2YbZgw!5e0!3m2!1sar!2seg!4v1687299712802!5m2!1sar!2seg"  style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>        </div>
    </div>
</section>
