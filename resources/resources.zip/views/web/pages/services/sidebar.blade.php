<div class="sidebar">

    <div class="sidebar-widget gallery-info-widget">
        <div class="gallery-info-item-wrap">
            <div class="gallery-info-item">
                <p><i class="ri-user-unfollow-line"></i>عدد العملاء:</p>
                <span>اكثر من 100 عميل</span>
            </div>
        </div>
    </div>
    <div class="sidebar-widget contact-widget bg-f hero-bg-12">
        <div class="overlay bg-prussian op-9"></div>
        <h3>تواصل معنا لطلب الخدمه</h3>
        <a href="tel:+966546339689">+966 54 633 9689</a>
        <a href="mailto:sales@excape-sa.com">sales@excape-sa.com</a>
        <a href="{{route('web.contactUs')}}" class="btn style2">اترك لنا رسالة </a>
        <div></div>
        <a target="_blank" href="https://wa.me/966546339689?text={{$service->name_ar}}  {{route('web.projects.show', $service->id)}}" class="btn bg-success style2">تواصل عبر الواتس اب</a>
    </div>
</div>
