@extends('web.master')

@section('content')

    @include('web.layouts.breadcrumb', ['title_page' => 'خدماتنا'])

    @include('web.pages.services.services')

    @include('web.pages.home.contact')

@endsection

@section('js')

    <script>

    </script>
@endsection
