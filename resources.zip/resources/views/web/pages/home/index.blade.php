@extends('web.master')

@section('content')

    @include('web.pages.home.slider')

    @include('web.pages.home.features')

    @include('web.pages.home.services')

    @include('web.pages.home.development')

    @include('web.pages.home.vide')

    @include('web.pages.home.whyUs')

    @include('web.pages.home.projects')

    @include('web.pages.home.clientsSays')


@endsection
