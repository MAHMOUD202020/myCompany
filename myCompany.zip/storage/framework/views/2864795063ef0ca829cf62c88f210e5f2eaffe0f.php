<?php ($block = $blocks->where('name' , 'development')->first()); ?>
<?php ($colors = ['bg-66a6ff', 'bg-05dbcf' , 'bg-fec66f' , 'bg-66a6ff', 'bg-66a6ff', 'bg-05dbcf' , 'bg-fec66f' , 'bg-66a6ff', 'bg-66a6ff', 'bg-05dbcf' , 'bg-fec66f' , 'bg-66a6ff', 'bg-66a6ff', 'bg-05dbcf' , 'bg-fec66f' , 'bg-66a6ff']); ?>
<!-- Start Development Area -->
<section class="development-area ptb-100">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <div class="development-image">
                    <img src="<?php echo e(asset("assets/web/images/block/$block->img")); ?>" alt="image">
                </div>
            </div>

            <div class="col-lg-6">
                <?php $__currentLoopData = $block->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="development-content">
                        <div class="icon <?php echo e($colors[$loop->index]); ?>">
                            <i class="<?php echo e($item->icon); ?>"></i>
                        </div>
                        <h3><?php echo e($item->title); ?></h3>
                        <p><?php echo e($item->text); ?></p>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>
<!-- End Development Area -->
<?php /**PATH C:\xampp\htdocs\myCompany\resources\views/web/pages/home/development.blade.php ENDPATH**/ ?>