<?php $__env->startSection('content'); ?>

    <!-- Start Page Title Area -->
    <div class="page-title-area item-bg-4" style='background-image: url("<?php echo e(asset("assets/web/images/pages/$page->cover")); ?>")'>
        <div class="d-table">
            <div class="d-table-cell">
                <div class="container">
                    <div class="page-title-content">
                        <h2><?php echo e($page->name); ?></h2>
                        <ul>
                            <li><a href="<?php echo e(route('web.home')); ?>"><?php echo app('translator')->get('layout.page-home'); ?></a></li>
                            <li><?php echo e($page->name); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Page Title Area -->

    <?php if(session()->has('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <label class="d-block"> <?php echo e($error); ?> </label>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

    <!-- Start Contact Box Area -->
    <section class="contact-box pt-100 pb-70">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $contacts->where('type' , 'contact'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6">
                        <div class="single-contact-box">
                            <i class="<?php echo e($contact->icon); ?>"></i>
                            <div class="content-title">
                                <h3><?php echo e($contact->title); ?></h3>
                                <p><?php echo e($contact->value); ?></p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <!-- End Contact Box Area -->

    <!-- Start Contact Area -->
    <section class="contact-section pb-100">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="contact-text">
                        <h3><?php echo app('translator')->get('form.label.Questions About'); ?></h3>
                        <p><?php echo app('translator')->get('form.label.Questions description'); ?></p>
                    </div>

                    <div class="contact-form">
                        <form id="contactForm" method="post" action="<?php echo e(route('web.contact.save')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label>Name</label>
                                <input type="text" name="name" value="<?php echo e(old('name')); ?>" id="name" class="form-control" required data-error="Please enter your name" placeholder="Name">
                                <div class="help-block with-errors"></div>
                            </div>

                            <div class="form-group">
                                <label>Email</label>
                                <input type="email" name="email" id="email" value="<?php echo e(old('email')); ?>" class="form-control" required data-error="Please enter your email" placeholder="Your Email">
                                <div class="help-block with-errors"></div>
                            </div>

                            <div class="form-group">
                                <label>Phone</label>
                                <input type="tel" name="phone" id="phone" value="<?php echo e(old('phone')); ?>" class="form-control" required data-error="Please enter your Phone" placeholder="Your Phone">
                                <div class="help-block with-errors"></div>
                            </div>

                            <div class="form-group">
                                <label>Subject</label>
                                <input type="text" name="subject" value="<?php echo e(old('subject')); ?>" id="msg_subject" class="form-control" required data-error="Please enter your subject" placeholder="Your Subject">
                                <div class="help-block with-errors"></div>
                            </div>

                            <div class="form-group">
                                <label>Message</label>
                                <textarea name="message" class="form-control" id="message" cols="30" rows="6" required data-error="Write your message" placeholder="Your Message"><?php echo e(old('message')); ?>"</textarea>
                                <div class="help-block with-errors"></div>
                            </div>

                            <div class="send-btn">
                                <button type="submit" class="default-btn">
                                    Send Message
                                </button>
                                <div id="msgSubmit" class="h3 text-center hidden"></div>
                                <div class="clearfix"></div>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="col-lg-6">
                    <div class="contact-image">
                        <img src="<?php echo e(asset('assets/web/images/contact.png')); ?>" alt="image">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End Contact Area -->


    <?php echo $page->content; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.master' , ['title_seo' => $page->name], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myCompany\resources\views/web/pages/contact/index.blade.php ENDPATH**/ ?>