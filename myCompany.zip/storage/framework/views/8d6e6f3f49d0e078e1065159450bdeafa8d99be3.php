<?php ($block = $blocks->where('name' , 'clientsSays')->first()); ?>

<!-- Start Clients Area -->
<section class="clients-section">
    <div class="container">
        <div class="section-title">
            <h2><?php echo e($block->title); ?></h2>
            <p><?php echo e($block->text); ?></p>
            <div class="bar"></div>
        </div>

        <div class="clients-slider owl-carousel owl-theme">

            <?php $__currentLoopData = $block->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="clients-item">
                    <div class="icon">
                        <i class="flaticon-left-quotes-sign"></i>
                    </div>

                    <p><?php echo e($item->text); ?></p>

                    <div class="clients-content">
                        <h3><?php echo e($item->title); ?></h3>
                    </div>
                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<!-- End Clients Area -->
<?php /**PATH C:\xampp\htdocs\myCompany\resources\views/web/pages/home/clientsSays.blade.php ENDPATH**/ ?>