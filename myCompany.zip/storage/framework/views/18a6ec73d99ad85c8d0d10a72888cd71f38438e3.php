<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.staticPages.index' , ['page' => $block->page])); ?>"><?php echo app('translator')->get("layout.blocks"); ?></a></li>
    <li class="breadcrumb-item active" aria-current="page"><span><?php echo e($block->title); ?></span></li>
    <li class="breadcrumb-item active" aria-current="page"><span><?php echo app('translator')->get('layout.items'); ?></span></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('admin.includes.alert_success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="bg-light p-3 mb-2"><h2><?php echo app('translator')->get('form.label.items block'); ?> <?php echo e($block->title); ?></h2></div>

    <?php if($items->count()): ?>
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row bg-light pt-3 pb-3">
                <div class="col-md-12">
                    <div class="h2 text-center"><?php echo app('translator')->get('form.label.title'); ?> : <?php echo e($item->title); ?></div>
                </div>

                <div class="col-md-12">
                    <p><?php echo app('translator')->get('form.label.text'); ?> : <?php echo e($item->text); ?></p>
                </div>

                <div class="col-md-12">
                    <p><?php echo app('translator')->get('form.label.icon'); ?> : <?php echo e($item->icon); ?></p>
                </div>

                <div class="col mt-3">
                    <a href="<?php echo e(route('admin.items.edit' , $item->id)); ?>" class="btn btn-success"><?php echo app('translator')->get('form.label.edit data'); ?></a>

                    <form method="post" action="<?php echo e(route('admin.items.destroy' , $item->id)); ?>" class="d-inline-block">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <input type="hidden" name="id" value="<?php echo e($item->id); ?>">
                        <button type="submit"  class="btn btn-danger"><?php echo app('translator')->get('form.label.delete'); ?></button>
                    </form>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <div class="alert alert-warning"><?php echo app('translator')->get('form.label.not any items'); ?></div>
    <?php endif; ?>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myCompany\resources\views/admin/pages/items/index.blade.php ENDPATH**/ ?>