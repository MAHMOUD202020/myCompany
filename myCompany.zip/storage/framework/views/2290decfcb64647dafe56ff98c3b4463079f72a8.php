<div class="container mt-3">

    <h3 class="title"> <?php echo app('translator')->get('form.label.items now'); ?></h3>

    <?php if($sliders->count()): ?>
        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row bg-light pt-3 pb-3">
                <div class="col-md-6">
                    <div class="item-img" style='background-image: url("<?php echo e(asset("assets/web/images/slider/$slider->img")); ?>")'></div>
                </div>

                <div class="col-md-6">
                    <div class="item-background" style='background-image: url("<?php echo e(asset("assets/web/images/slider/$slider->background")); ?>")'></div>

                    <hr>

                    <div class="h2 text-center"><?php echo e($slider->title); ?></div>

                    <p><?php echo e($slider->text); ?></p>

                    <hr>

                    <?php if($slider->btn_text): ?>
                        <p><?php echo app('translator')->get('form.label.btn text'); ?> : <?php echo e($slider->btn_text); ?></p>
                    <?php endif; ?>

                    <?php if($slider->url): ?>
                        <p><?php echo app('translator')->get('form.label.link'); ?> : <?php echo e($slider->url); ?></p>
                    <?php endif; ?>

                </div>

                <div class="col mt-3">
                    <a href="<?php echo e(route('admin.sliders.edit' , $slider->id)); ?>" class="btn btn-success"><?php echo app('translator')->get('form.label.edit data'); ?></a>

                    <form method="post" action="<?php echo e(route('admin.sliders.destroy' , $slider->id)); ?>" class="d-inline-block">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button type="submit"  class="btn btn-danger"><?php echo app('translator')->get('form.label.delete'); ?></button>
                    </form>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <div class="alert alert-warning"><?php echo app('translator')->get('form.label.not any items'); ?></div>
    <?php endif; ?>

</div>
<?php /**PATH C:\xampp\htdocs\myCompany\resources\views/admin/pages/sliders/show.blade.php ENDPATH**/ ?>