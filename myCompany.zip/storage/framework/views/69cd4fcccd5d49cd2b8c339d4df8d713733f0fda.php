<div class="container mt-3">

    <h3 class="title"> <?php echo app('translator')->get('form.label.items now'); ?></h3>

    <?php if($items->count()): ?>
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row bg-light pt-3 pb-3">
                <div class="col-md-6">
                    <div class="item-img" style='background-image: url("<?php echo e(asset("assets/web/images/slider/$item->img")); ?>")'></div>
                </div>

                <div class="col-md-6">
                    <div class="item-background" style='background-image: url("<?php echo e(asset("assets/web/images/slider/$item->background")); ?>")'></div>

                    <hr>

                    <div class="h2 text-center"><?php echo e($item->title); ?></div>

                    <p><?php echo e($item->text); ?></p>

                    <hr>

                    <?php if($item->btn_text): ?>
                        <p><?php echo app('translator')->get('form.label.btn text'); ?> : <?php echo e($item->btn_text); ?></p>
                    <?php endif; ?>
                    <?php if($item->url): ?>
                        <p><?php echo app('translator')->get('form.label.link'); ?> : <?php echo e($item->url); ?></p>
                    <?php endif; ?>
                </div>

                <div class="col mt-3">
                    <a href="<?php echo e(route('admin.pages.home.edit' , ['slider' , $item->id])); ?>" class="btn btn-success"><?php echo app('translator')->get('form.label.edit data'); ?></a>

                    <form method="post" action="<?php echo e(route('admin.pages.home.delete' , 'slider')); ?>" class="d-inline-block">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <input type="hidden" name="id" value="<?php echo e($item->id); ?>">
                        <button type="submit"  class="btn btn-danger"><?php echo app('translator')->get('form.label.delete'); ?></button>
                    </form>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <div class="alert alert-warning"><?php echo app('translator')->get('form.label.not any items'); ?></div>
    <?php endif; ?>

</div>
<?php /**PATH C:\xampp\htdocs\myCompany\resources\views/admin/pages/homePage/slider/show.blade.php ENDPATH**/ ?>