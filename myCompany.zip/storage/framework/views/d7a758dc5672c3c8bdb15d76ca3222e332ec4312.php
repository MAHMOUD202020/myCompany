<div class="container mt-3">

    <h3 class="title"> <?php echo app('translator')->get('form.label.items now'); ?></h3>

    <?php if($items->count()): ?>
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row bg-light pt-3 pb-3">
                <div class="col-md-12">
                    <div class="h2 text-center"><?php echo app('translator')->get('form.label.title'); ?> : <?php echo e($item->title); ?></div>
                </div>

                <div class="col-md-12">
                    <p><?php echo app('translator')->get('form.label.text'); ?> : <?php echo e($item->text); ?></p>
                </div>

                <div class="col-md-12">
                    <p><?php echo app('translator')->get('form.label.icon'); ?> : <?php echo e($item->icon); ?></p>
                </div>

                <div class="col mt-3">
                    <a href="<?php echo e(route('admin.pages.home.edit' , ['feature' , $item->id])); ?>" class="btn btn-success"><?php echo app('translator')->get('form.label.edit data'); ?></a>

                    <form method="post" action="<?php echo e(route('admin.pages.home.delete' , 'feature')); ?>" class="d-inline-block">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <input type="hidden" name="id" value="<?php echo e($item->id); ?>">
                        <button type="submit"  class="btn btn-danger"><?php echo app('translator')->get('form.label.delete'); ?></button>
                    </form>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <div class="alert alert-warning"><?php echo app('translator')->get('form.label.not any items'); ?></div>
    <?php endif; ?>

</div>
<?php /**PATH C:\xampp\htdocs\myCompany\resources\views/admin/pages/homePage/feature/show.blade.php ENDPATH**/ ?>