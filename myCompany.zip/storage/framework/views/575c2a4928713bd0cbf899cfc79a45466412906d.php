<?php $__env->startSection('breadcrumb'); ?>
    <?php if(!IS_TRASH): ?>
        <li class="breadcrumb-item active" aria-current="page"><span><?php echo app('translator')->get('layout.users'); ?></span></li>
    <?php else: ?>
        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.users.index')); ?>"><?php echo app('translator')->get('layout.users'); ?></a></li>
        <li class="breadcrumb-item active" aria-current="page"><span><?php echo app('translator')->get('layout.trash'); ?></span></li>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('admin.includes.modalBtnAction', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo myDataTable_button([
        __('layout.add user') => route('admin.users.create'),
      ]); ?>




    <?php echo myDataTable_table([
        "id"           => 'id',
        "name"         => __('form.label.name'),
        "email"        => __('form.label.email'),
        "phone"        => __('form.label.phone'),
        "updated_at"   => __('form.label.updated_at'),
        "created_at"   => __('form.label.created_at'),
    ]); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset("assets/myDataTable/data.css")); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset("assets/myDataTable/data.js")); ?>"></script>
    <script>

        myDataTableColumns({
            name   :  ['id', 'name', 'email', 'phone', 'updated_at', 'created_at'],
            class  : {'updated_at': 'notEdit' , 'created_at': 'notEdit', 'password':'d-none'},
            btn    :  {

                'edit'         : '<?php echo e(route('admin.users.update' , '')); ?>'+'/{id}',

                <?php if(!IS_TRASH): ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role' , 'category.destroy')): ?>
                    'delete'       : '<?php echo e(route('admin.users.destroy' , '')); ?>'+'/{id}',
                    <?php endif; ?>
                <?php else: ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role' , 'category.restore')): ?>
                    'restore'      : '<?php echo e(route('admin.users.restore' , '')); ?>'+'/{id}',
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role' , 'category.finalDelete')): ?>
                    'delete'       : '<?php echo e(route('admin.users.finalDelete' , '')); ?>'+'/{id}',
                    <?php endif; ?>
                <?php endif; ?>

                'print'        : '#',

            }
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myCompany\resources\views/Admin/pages/users/index.blade.php ENDPATH**/ ?>