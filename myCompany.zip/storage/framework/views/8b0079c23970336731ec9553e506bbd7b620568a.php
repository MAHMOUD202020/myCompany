<?php ($dir = app()->getLocale() === 'ar' ? 'rtl': 'ltr'); ?>

<!doctype html>
<html lang="ar" dir="<?php echo e($dir); ?>">
<head>

    <?php ($title = isset($title_seo) ? "$title_seo | شركة البروف el prof company " : 'شركة البروف el prof company'); ?>
    <?php ($description = isset($description_seo) ? $description_seo : "شركة البروف للبرمجة وخدمات  تكنولوجيا المعلومات"); ?>
    <?php ($img =  isset($img_seo) ? $img_seo : asset('assets/web/img/logo.png')); ?>

    <?php echo $__env->make('web.layouts.meta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <title><?php echo e($title); ?></title>

    <?php echo $__env->make('web.layouts.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('css'); ?>

</head>

<body>

    <?php echo $__env->make('web.layouts.preloader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('web.layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!-- start content -->
    <?php echo $__env->yieldContent('content'); ?>
    <!-- end content -->

    <?php echo $__env->make('web.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('web.layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('js'); ?>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\myCompany\resources\views/web/master.blade.php ENDPATH**/ ?>