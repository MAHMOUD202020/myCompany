<?php $__env->startSection('content'); ?>

    <!-- Start Page Title Area -->
    <div class="page-title-area item-bg-4" style='background-image: url("<?php echo e(asset("assets/web/images/projects/$project->cover")); ?>")'>
        <div class="d-table">
            <div class="d-table-cell">
                <div class="container">
                    <div class="page-title-content">
                        <h2><?php echo e($project["name_$lang"]); ?></h2>
                        <ul>
                            <li><a href="<?php echo e(route('web.home')); ?>"><?php echo app('translator')->get('layout.page-home'); ?></a></li>
                            <li><?php echo app('translator')->get('layout.projects'); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Page Title Area -->

    <!-- Start Services Details Area -->
    <section class="projects-details-area ptb-100">
        <div class="container">
            <?php echo $project["description_$lang"]; ?>

        </div>
    </section>
    <!-- End Services Details Area -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.master' , ['title_seo' => $project["name_$lang"], 'img_seo' => asset("assets/web/images/projects/$project->img")], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myCompany\resources\views/web/pages/projects/show.blade.php ENDPATH**/ ?>