<?php $__env->startSection('content'); ?>

    <div class="container mt-3">
        <div class="row bg-light pt-3 pb-3">
            <div class="col-md-6">
                <div class="slider-img" style='background-image: url("<?php echo e(asset('assets/web/images/slider/1.png')); ?>")'></div>
            </div>

            <div class="col-md-6">
                <div class="h2 text-center">Lorem ipsum dolor sit amet, consectetur adipisicing</div>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. At, in, obcaecati. Atque eveniet illum quisquam quo rem. A aperiam blanditiis dicta doloremque molestiae, nam neque odit, possimus quos repellendus, sapiente.
            </div>

            <div class="col mt-3">
                <a href="" class="btn btn-success">تعديل</a>
                <a href="" class="btn btn-danger">حذف</a>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('css'); ?>
    <style>
        .slider-img{
            height: 300px;
            border: 1px solid;
            background-size:cover;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myCompany\resources\views/admin/pages/homePage/slider.blade.php ENDPATH**/ ?>