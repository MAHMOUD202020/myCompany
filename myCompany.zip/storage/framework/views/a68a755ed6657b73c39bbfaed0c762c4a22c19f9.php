<?php $__env->startSection('breadcrumb'); ?>
    <?php if(!IS_TRASH): ?>
        <li class="breadcrumb-item active" aria-current="page"><span><?php echo app('translator')->get('layout.sort sections'); ?></span></li>
    <?php else: ?>
        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.sections.index')); ?>"><?php echo app('translator')->get('layout.sort sections'); ?></a></li>
        <li class="breadcrumb-item active" aria-current="page"><span><?php echo app('translator')->get('layout.trash'); ?></span></li>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('admin.includes.modalBtnAction', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo myDataTable_button([
        __('layout.add section') => route('admin.sections.create'),
      ]); ?>




    <?php echo myDataTable_table([
        "id"             => 'id',
        "name_ar"        => __('form.label.name ar'),
        "name_en"        => __('form.label.name en'),
        "slug"           => __('form.label.slug'),
        "sub_categories_count" => [__('form.label.count categories'), true , false],
        "url"           => __('form.label.link'),
    ]); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset("assets/myDataTable/data.css")); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset("assets/myDataTable/data.js")); ?>"></script>
    <script>



        myDataTableColumns({
            name   :  ['id', 'name_ar', 'name_en', 'slug',  'sub_categories_count', 'url'],
            class  : {'updated_at': 'notEdit' , 'created_at': 'notEdit', 'sub_categories_count':'notEdit' },
            btn    :  {

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role' , 'section.update')): ?>
                'edit': '<?php echo e(route('admin.sections.update' , '')); ?>'+'/{id}',
                <?php endif; ?>

                <?php if(!IS_TRASH): ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role' , 'section.destroy')): ?>
                    'delete': '<?php echo e(route('admin.sections.destroy' , '')); ?>'+'/{id}',
                    <?php endif; ?>

                <?php else: ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role' , 'section.restore')): ?>
                    'restore': '<?php echo e(route('admin.sections.restore' , '')); ?>'+'/{id}',
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role' , 'section.finalDelete')): ?>
                    'delete': '<?php echo e(route('admin.sections.finalDelete' , '')); ?>'+'/{id}',
                    <?php endif; ?>

                <?php endif; ?>
                'print': '#',

            }
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myCompany\resources\views/admin/pages/sections/index.blade.php ENDPATH**/ ?>