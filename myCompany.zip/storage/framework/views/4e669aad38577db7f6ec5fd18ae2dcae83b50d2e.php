<?php ($block = $blocks->where('name' , 'whyUs')->first()); ?>

<!-- Start Choose Area -->
<section class="choose-section ptb-100">
    <div class="container">
        <div class="section-title">
            <h2><?php echo e($block->title); ?></h2>
            <p><?php echo e($block->text); ?></p>
            <div class="bar"></div>
        </div>

        <div class="row align-items-center">
            <div class="col-lg-6">
                <?php $__currentLoopData = $block->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="choose-content">
                    <div class="icon">
                        <i class="flaticon-shared-folder"></i>
                    </div>
                    <h3><?php echo e($item->title); ?></h3>
                    <p><?php echo e($item->text); ?></p>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="col-lg-6">
                <div class="choose-image">
                    <img src="<?php echo e(asset("assets/web/images/block/$block->img")); ?>" alt="image">
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End Choose Area -->
<?php /**PATH C:\xampp\htdocs\myCompany\resources\views/web/pages/home/whyUs.blade.php ENDPATH**/ ?>