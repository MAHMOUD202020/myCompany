<!-- Start Footer Area -->
<section class="footer-section pt-100 pb-70 mt-5">
    <div class="container">
        <div class="subscribe-area">
            <div class="row align-items-center">
                <div class="col-lg-6 col-md-6">
                    <div class="subscribe-content">
                        <h2><?php echo app('translator')->get('form.label.newsletter title'); ?></h2>
                        <p><?php echo app('translator')->get('form.label.newsletter description'); ?></p>
                    </div>
                </div>

                <div class="col-lg-6 col-md-6">
                    <form class="newsletter-form" method="post" action="<?php echo e(route('web.saveNewsletter')); ?>">
                        <input type="email" class="input-newsletter" placeholder="Enter your email" name="EMAIL" required autocomplete="off">
                        <button type="submit">
                            <?php echo app('translator')->get('form.label.Subscribe Now'); ?>
                        </button>

                        <div id="validator-newsletter" class="form-result"></div>
                    </form>
                </div>
            </div>
        </div>

    </div>
</section>
<!-- End Footer Area -->

<!-- Start Copy Right Area -->
<div class="copyright-area">
    <div class="container">
        <div class="copyright-area-content">
            <div class="row align-items-center">
                <div class="col-lg-6 col-md-6">
                    <p>
                        Copyright © 2021 Fria All Rights Reserved by
                        <a href="" target="_blank">
                            El Prof
                        </a>
                    </p>
                </div>

            </div>
        </div>
    </div>
</div>
<!-- End Copy Right Area -->

<!-- Start Go Top Section -->
<div class="go-top">
    <i class="bx bx-chevron-up"></i>
    <i class="bx bx-chevron-up"></i>
</div>
<!-- End Go Top Section -->
<?php /**PATH C:\xampp\htdocs\myCompany\resources\views/web/layouts/footer.blade.php ENDPATH**/ ?>