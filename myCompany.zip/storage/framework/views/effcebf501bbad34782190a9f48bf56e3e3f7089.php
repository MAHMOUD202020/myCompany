<form action="<?php echo e(route('admin.sections.sort.save')); ?>" method="post">
    <?php echo csrf_field(); ?>
<div class="col-lg-12 layout-spacing">
    <div class="statbox widget box box-shadow">
        <div class="widget-header">
            <div class="row">
                <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                    <h4><?php echo app('translator')->get('layout.sort sections'); ?></h4>
                </div>
            </div>
        </div>
        <div class="widget-content widget-content-area">

            <div class='parent ex-3'>
                <div class='row'>

                    <div class="col-md-6">
                            <div id='section-0' class='dragula rm-spill'>

                                <?php if($sections->count() > 0): ?>

                                    <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="media d-block d-sm-flex text-sm-left text-center">
                                            <div class="media-body">
                                                <h5 class=""><?php echo e($section->name_ar); ?> - (<?php echo e($section->sub_categories_count); ?>) <?php echo app('translator')->get('form.label.categories'); ?> </h5>
                                                <input type="hidden" name="sections[]" value="<?php echo e($section->id); ?>">
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php else: ?>

                                    <div class="alert alert-info p-3"><?php echo app('translator')->get('form.label.not any section'); ?></div>

                                <?php endif; ?>


                            </div>
                        </div>

                </div>
            </div>


        </div>
    </div>
</div>
    <button type="submit" class="btn btn-success d-block w-100"> <?php echo app('translator')->get('form.label.save sort'); ?></button>

</form>
<?php /**PATH C:\xampp\htdocs\myCompany\resources\views/admin/pages/sections/form_sort.blade.php ENDPATH**/ ?>