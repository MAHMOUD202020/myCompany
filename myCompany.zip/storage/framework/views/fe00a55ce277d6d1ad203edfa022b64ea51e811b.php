<?php $__env->startSection('content'); ?>
    <div class="form-container outer">
        <div class="form-form">
            <div class="form-form-wrap">
                <div class="form-container">
                    <div class="form-content">

                        <h1 class=""><?php echo app('translator')->get('form.label.login'); ?></h1>
                        <p class=""><?php echo app('translator')->get('form.label.login Admin'); ?></p>

                        <?php echo $__env->make('admin.auth.form_login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="division mt-2">
                        </div>
                        <a  class="dropdown-item d-flex" href="<?php echo e(route('admin.lang.change' , 'ar')); ?>"><img width="25" src="<?php echo e(asset('assets/Admin/img/ar.png')); ?>" class="flag-width" alt="flag"> <span class="align-self-center">&nbsp;العربية</span></a>
                        <a class="dropdown-item d-flex" href="<?php echo e(route('admin.lang.change' , 'en')); ?>"><img  width="25" src="<?php echo e(asset('assets/Admin/img/ca.png')); ?>" class="flag-width" alt="flag"> <span class="align-self-center">&nbsp;English</span></a>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.masterAuth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myCompany\resources\views/admin/auth/login.blade.php ENDPATH**/ ?>