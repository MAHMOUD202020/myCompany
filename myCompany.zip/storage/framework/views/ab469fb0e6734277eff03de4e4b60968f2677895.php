<!-- BEGIN LOADER -->
<div id="load_screen"> <div class="loader"> <div class="loader-content">
            <div class="spinner-grow align-self-center"></div>
        </div></div></div>
<!--  END LOADER -->
<?php /**PATH C:\xampp\htdocs\myCompany\resources\views/admin/includes/load_screen.blade.php ENDPATH**/ ?>