<?php ($block = $blocks->where('name', 'projects')->first()); ?>

<!-- Start Projects Area -->
<section class="projects-section pb-70">
    <div class="container-fluid">
        <div class="section-title">
            <h2><?php echo e($block->title); ?></h2>
            <p><?php echo e($block->text); ?></p>
            <div class="bar"></div>
        </div>

        <div class="row">
            <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4">
                    <div class="single-projects">
                        <div class="projects-image">
                            <img src="<?php echo e(asset("assets/web/images/projects/$project->img")); ?>" alt="image">
                        </div>

                        <div class="projects-content">
                            <a href="<?php echo e(route('web.projects.show' , $project->id)); ?>">
                                <h3><?php echo e($project->name); ?></h3>
                            </a>

                            <a href="<?php echo e(route('web.projects.show' , $project->id)); ?>">
                                <span><?php echo e($project->category); ?></span>
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<!-- End Projects Area -->
<?php /**PATH C:\xampp\htdocs\myCompany\resources\views/web/pages/home/projects.blade.php ENDPATH**/ ?>