<?php $__env->startSection('breadcrumb'); ?>
    <?php if(!IS_TRASH): ?>
        <li class="breadcrumb-item active" aria-current="page"><span><?php echo app('translator')->get('layout.admins'); ?></span></li>
    <?php else: ?>
        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.admins.index')); ?>"><?php echo app('translator')->get('layout.admins'); ?></a></li>
        <li class="breadcrumb-item active" aria-current="page"><span><?php echo app('translator')->get('layout.trash'); ?></span></li>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('admin.includes.modalBtnAction', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo myDataTable_button([
        __('layout.add Admin') => route('admin.admins.create'),
      ]); ?>




    <?php echo myDataTable_table([
        "id"           => 'id',
        "name"         => __('form.label.name'),
        "email"        => __('form.label.email'),
        "phone"        => __('form.label.phone'),
        "role_id"      => __('form.label.role'),
        "password"     => [__('form.label.password') , false, false , 'all', 'd-none'],
        "updated_at"   => __('form.label.updated_at'),
        "created_at"   => __('form.label.created_at'),
    ]); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset("assets/myDataTable/data.css")); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset("assets/myDataTable/data.js")); ?>"></script>
    <script>

        let role_id = '<?php echo json_encode($roles, 15, 512) ?>';


        myDataTableColumns({
            name   :  ['id', 'name', 'email', 'phone', 'role_id', 'password',  'updated_at', 'created_at'],
            class  : {'updated_at': 'notEdit' , 'created_at': 'notEdit', 'password':'d-none'},
            alias  : {role_id},
            select : {role_id},
            btn    :  {

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role' , 'admin.update')): ?>
                'edit'         : '<?php echo e(route('admin.admins.update' , '')); ?>'+'/{id}',
                <?php endif; ?>

                <?php if(!IS_TRASH): ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role' , 'admin.destroy')): ?>
                    'delete'       : '<?php echo e(route('admin.admins.destroy' , '')); ?>'+'/{id}',
                    <?php endif; ?>

                <?php else: ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role' , 'admin.restore')): ?>
                    'restore'      : '<?php echo e(route('admin.admins.restore' , '')); ?>'+'/{id}',
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role' , 'admin.finalDelete')): ?>
                    'delete'       : '<?php echo e(route('admin.admins.finalDelete' , '')); ?>'+'/{id}',
                    <?php endif; ?>

                <?php endif; ?>

                'print'        : '#',

            }
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myCompany\resources\views/Admin/pages/admins/index.blade.php ENDPATH**/ ?>