<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">


<?php /**PATH C:\xampp\htdocs\myCompany\resources\views/admin/includes/meta.blade.php ENDPATH**/ ?>