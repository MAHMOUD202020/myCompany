<?php $__env->startSection('content'); ?>

    <!-- Start Page Title Area -->
    <div class="page-title-area item-bg-4" style='background-image: url("<?php echo e(asset("assets/web/images/pages/$page->cover")); ?>")'>
        <div class="d-table">
            <div class="d-table-cell">
                <div class="container">
                    <div class="page-title-content">
                        <h2><?php echo e($page->name); ?></h2>
                        <ul>
                            <li><a href="<?php echo e(route('web.home')); ?>"><?php echo app('translator')->get('layout.page-home'); ?></a></li>
                            <li><?php echo e($page->name); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Page Title Area -->

    <!-- Start About Area -->
    <?php ($aboutCompany = $blocks->where('name' , 'aboutCompany')->first()); ?>

    <section class="about-section ptb-100">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6 p-0">
                    <div >
                        <img src="<?php echo e(asset("assets/web/images/block/$aboutCompany->img")); ?>" alt="image">
                    </div>
                </div>

                <div class="col-lg-6">
                    <div class="about-tab">
                        <h2><?php echo e($aboutCompany->title); ?></h2>
                        <div class="bar"></div>
                        <p><?php echo e($aboutCompany->text); ?></p>

                        <div class="tab about-list-tab">
                            <ul class="tabs">
                                <?php $__currentLoopData = $aboutCompany->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <a href="#">
                                       <?php echo e($item->title); ?>

                                    </a>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>

                            <div class="tab_content">
                                <?php $__currentLoopData = $aboutCompany->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="tabs_item">
                                        <?php echo e($item->text); ?>

                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End About Area -->

    <?php echo $__env->make('web.pages.home.clientsSays', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section class="protfolio-section pt-100 pb-100">
        <div class="container">
            <?php echo $page->description; ?>

        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.master' , ['title_seo' => $page->name], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myCompany\resources\views/web/pages/about/index.blade.php ENDPATH**/ ?>