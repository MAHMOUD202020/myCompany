<?php ($block = $blocks->where('name' , 'features')->first()); ?>
<!-- Start Features Area -->
<section class="features-section pt-100 pb-70">
    <div class="container">
        <div class="section-title">
            <h2><?php echo e($block->title); ?></h2>
            <p><?php echo e($block->text); ?></p>
            <div class="bar"></div>
        </div>

        <div class="row">
            <?php $__currentLoopData = $block->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 col-md-6">
                    <div class="features-content">
                        <div class="icon">
                            <i class="<?php echo e($item->icon); ?>"></i>
                        </div>
                        <h3><?php echo e($item->title); ?></h3>
                        <p><?php echo e($item->text); ?></p>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<!-- End Features Area -->
<?php /**PATH C:\xampp\htdocs\myCompany\resources\views/web/home/features.blade.php ENDPATH**/ ?>