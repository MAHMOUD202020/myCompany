<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item active" aria-current="page"><span><?php echo app('translator')->get('layout.staticPages'); ?></span></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('admin.includes.alert_success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <?php $__currentLoopData = $blocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="row bg-light pt-3 pb-3">


            <div class="col-md-6">
                <div class="h2 text-center"><?php echo e($block->title); ?></div>

                <p><?php echo e($block->text); ?></p>

                <hr>

                <?php if($block->btn_text): ?>
                    <p><?php echo app('translator')->get('form.label.btn text'); ?> : <?php echo e($block->btn_text); ?></p>
                <?php endif; ?>

                <?php if($block->url): ?>
                    <p><?php echo app('translator')->get('form.label.link'); ?> : <?php echo e($block->url); ?></p>
                <?php endif; ?>
                <div class="col-md-12">
                    <div class="item-img" style='background-image: url("<?php echo e(asset("assets/web/images/slider/$block->img")); ?>")'></div>
                </div>

            </div>

            <div class="col">
                <a href="<?php echo e(route('admin.staticPages.edit' , $block->id)); ?>" class="btn btn-success"><?php echo app('translator')->get('form.label.edit data'); ?></a>

                <a href="<?php echo e(route('admin.items.index', ['block' => $block->id])); ?>" class="btn btn-primary <?php echo e(!$block->is_container ? 'disabled' : ''); ?>"><?php echo app('translator')->get('form.label.show items'); ?></a>

                <a href="<?php echo e(route('admin.items.create', ['block' => $block->id])); ?>" class="btn btn-info <?php echo e(!$block->is_container ? 'disabled' : ''); ?>"><?php echo app('translator')->get('form.label.add item'); ?></a>

            </div>
        </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myCompany\resources\views/admin/pages/block/index.blade.php ENDPATH**/ ?>