<meta charset="utf-8">


<meta name="title" content="<?php echo e($title); ?>">
<meta name="description" content="<?php echo e($description); ?>">
<meta name="keywords" content="<?php if(isset($keywords_seo)): ?> <?php echo e($keywords_seo); ?> <?php else: ?> برمجة,نظم,معلومات,هاتف,اندرويد,ios,تطبيقات الهاتف,تطبيقات الويب  <?php endif; ?>">
<meta name="robots" content="index, follow">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="language" content="Arabic">

<!-- Open Graph / Facebook -->
<meta property="og:type" content="website">
<meta property="og:url" content="">
<meta property="og:title" content="<?php echo e($title); ?>">
<meta property="og:description" content="<?php echo e($description); ?>">
<meta property="og:image" content="<?php echo e($img); ?>">

<!-- Twitter -->
<meta property="twitter:card" content="summary_large_image">
<meta property="twitter:url" content="https://twitter.com/StoreMeral">
<meta property="twitter:title" content="<?php echo e($title); ?>">
<meta property="twitter:description" content="<?php echo e($description); ?>">
<meta property="twitter:image" content="<?php echo e($img); ?>">

<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<meta name="format-detection" content="telephone=no">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<link rel="icon" href="<?php echo e(asset('assets/web/img/logo-icon.png')); ?>">
<?php /**PATH C:\xampp\htdocs\myCompany\resources\views/web/layouts/meta.blade.php ENDPATH**/ ?>