<form action="<?php echo e(route('admin.categories.sort.save')); ?>" method="post">
    <?php echo csrf_field(); ?>
<div class="col-lg-12 layout-spacing">
    <div class="statbox widget box box-shadow">
        <div class="widget-header">
            <div class="row">
                <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                    <h4><?php echo app('translator')->get('form.label.sort category'); ?></h4>
                </div>
            </div>
        </div>
        <div class="widget-content widget-content-area">

            <div class='parent ex-3'>
                <div class='row'>

                    <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6">
                        <h2><?php echo app('translator')->get('form.label.categories sections'); ?> : <?php echo e($section["name_$lang"]); ?></h2>
                            <div id='section-<?php echo e($loop->index); ?>' class='dragula rm-spill'>

                                <?php if($section->subCategories->count() > 0): ?>

                                    <?php $__currentLoopData = $section->subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="media d-block d-sm-flex text-sm-left text-center">
                                            <div class="media-body">
                                                <h5 class=""><?php echo e($category->name_ar); ?> </h5>
                                                <input type="hidden" name="sections[<?php echo e($section->id); ?>][]" value="<?php echo e($category->id); ?>">
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php else: ?>

                                    <div class="alert alert-info p-3"><?php echo app('translator')->get('form.label.not any category in this sections'); ?></div>

                                <?php endif; ?>


                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>


        </div>
    </div>
</div>
    <button type="submit" class="btn btn-success d-block w-100"><?php echo app('translator')->get('form.label.save sort'); ?></button>

</form>
<?php /**PATH C:\xampp\htdocs\myCompany\resources\views/admin/pages/categories/form_sort.blade.php ENDPATH**/ ?>