<?php if(session()->has('success')): ?>

    <br>

    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>

<?php endif; ?>

<?php /**PATH C:\xampp\htdocs\myCompany\resources\views/admin/includes/alert_success.blade.php ENDPATH**/ ?>