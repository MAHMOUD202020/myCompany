<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.admins.index')); ?>"><?php echo app('translator')->get('layout.admins'); ?></a></li>
    <li class="breadcrumb-item active" aria-current="page"><span><?php echo app('translator')->get('layout.add Admin'); ?></span></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="account-settings-container layout-top-spacing">

        <div class="account-content">
            <div class="scrollspy-example" data-spy="scroll" data-target="#account-settings-scroll" data-offset="-100">
                <div class="row">

                    <div class="col-xl-12 col-lg-12 col-md-12 layout-spacing">
                        <?php echo $__env->make('admin.includes.alert_success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <div class="widget-content widget-content-area">
                            <?php echo $__env->make('admin.pages.admins.form_create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

    <script src="<?php echo e(asset('assets/Admin/plugins/bootstrap-maxlength/bootstrap-maxlength.js')); ?>"></script>

    <script>
        $('input').maxlength({
            threshold: 40,
        });

        $(function () {

            function makeid(length) {
                var result           = '';
                var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
                var charactersLength = characters.length;
                for ( var i = 0; i < length; i++ ) {
                    result += characters.charAt(Math.floor(Math.random() *
                        charactersLength));
                }
                return result;
            }

            $('.btn-password-generator').on('click' , function (){
                $('#password').val(makeid(15))
            })

        });

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myCompany\resources\views/admin/pages/admins/create.blade.php ENDPATH**/ ?>