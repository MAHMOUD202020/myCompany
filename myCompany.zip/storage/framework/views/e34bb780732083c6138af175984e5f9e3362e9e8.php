<?php $__env->startSection('content'); ?>

    <div class="layout-px-spacing">
        <div class="row layout-top-spacing">
            <div class="col-xl-12 col-lg-12 col-md-12">

                <div class="row">

                    <div class="col-xl-12  col-md-12">

                        <div class="mail-box-container">
                            <div class="mail-overlay"></div>


                            <div id="mailbox-inbox" class="accordion mailbox-inbox">


                                <?php echo $__env->make('admin.pages.messages.btnAction', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                <?php echo $__env->make('admin.pages.messages.messageBox', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                <?php echo $__env->make('admin.pages.messages.contentBox', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                            </div>

                        </div>

                    </div>


                </div>

            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

    <link href="<?php echo e(asset('assets/Admin/css/apps/mailbox.css')); ?>" rel="stylesheet" type="text/css" />





<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>


    <script src="<?php echo e(asset('assets/Admin/plugins/sweetalerts/sweetalert2.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/Admin/js/apps/custom-mailbox.js')); ?>"></script>


<script>
    $(function (){

        $('.delete-message').on('click', function (e) {

            e.preventDefault();
            e.stopPropagation();
            $(this).parents('.mailInbox').hide(500)

            $.ajax({
                method:'delete',
                url:$(this).attr('href'),
            })
        })
    })
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myCompany\resources\views/admin/pages/messages/index.blade.php ENDPATH**/ ?>