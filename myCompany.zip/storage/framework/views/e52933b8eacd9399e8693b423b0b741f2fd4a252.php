<?php ($block = $blocks->where('name', 'projects')->first()); ?>

<!-- Start Projects Area -->
<section class="projects-section pb-70">
    <div class="container-fluid">
        <div class="section-title">
            <h2><?php echo e($block->title); ?></h2>
            <p><?php echo e($block->text); ?></p>
            <div class="bar"></div>
        </div>

        <div class="row">
            <div class="col-lg-4">
                <div class="single-projects">
                    <div class="projects-image">
                        <img src="<?php echo e(asset('assets/web/img/projects/1.jpg')); ?>" alt="image">
                    </div>

                    <div class="projects-content">
                        <a href="single-projects.html">
                            <h3>App Update & Rebrand</h3>
                        </a>

                        <a href="single-projects.html">
                            <span>Research and startup</span>
                        </a>
                    </div>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="single-projects">
                    <div class="projects-image">
                        <img src="<?php echo e(asset('assets/web/img/projects/2.jpg')); ?>" alt="image">
                    </div>

                    <div class="projects-content">
                        <a href="single-projects.html">
                            <h3>IT Consultancy</h3>
                        </a>

                        <a href="single-projects.html">
                            <span>Research and startup</span>
                        </a>
                    </div>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="single-projects">
                    <div class="projects-image">
                        <img src="<?php echo e(asset('assets/web/img/projects/3.jpg')); ?>" alt="image">
                    </div>

                    <div class="projects-content">
                        <a href="single-projects.html">
                            <h3>Digital Marketing</h3>
                        </a>

                        <a href="single-projects.html">
                            <span>Research and startup</span>
                        </a>
                    </div>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="single-projects">
                    <div class="projects-image">
                        <img src="<?php echo e(asset('assets/web/img/projects/4.jpg')); ?>" alt="image">
                    </div>

                    <div class="projects-content">
                        <a href="single-projects.html">
                            <h3>App Development</h3>
                        </a>

                        <a href="single-projects.html">
                            <span>Research and startup</span>
                        </a>
                    </div>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="single-projects">
                    <div class="projects-image">
                        <img src="<?php echo e(asset('assets/web/img/projects/5.jpg')); ?>" alt="image">
                    </div>

                    <div class="projects-content">
                        <a href="single-projects.html">
                            <h3>IT Solutions</h3>
                        </a>

                        <a href="single-projects.html">
                            <span>Research and startup</span>
                        </a>
                    </div>
                </div>

                <div class="single-projects">
                    <div class="projects-image">
                        <img src="<?php echo e(asset('assets/web/img/projects/6.jpg')); ?>" alt="image">
                    </div>

                    <div class="projects-content">
                        <a href="single-projects.html">
                            <h3>Data Management</h3>
                        </a>

                        <a href="single-projects.html">
                            <span>Research and startup</span>
                        </a>
                    </div>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="single-projects">
                    <div class="projects-image">
                        <img src="<?php echo e(asset('assets/web/img/projects/7.jpg')); ?>" alt="image">
                    </div>

                    <div class="projects-content">
                        <a href="single-projects.html">
                            <h3>E-commerce Development</h3>
                        </a>

                        <a href="single-projects.html">
                            <span>Research and startup</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End Projects Area -->
<?php /**PATH C:\xampp\htdocs\myCompany\resources\views/web/home/projects.blade.php ENDPATH**/ ?>