<div class="sidebar-wrapper sidebar-theme">

    <nav id="sidebar">
        <div class="shadow-bottom"></div>
        <ul class="list-unstyled menu-categories" id="accordionExample">

            
            <li class="menu">
                <a href="#dashboard" data-toggle="collapse" data-active="false" aria-expanded="false" class="dropdown-toggle" id="toggle-dashboard">
                    <div class="">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-cpu"><rect x="4" y="4" width="16" height="16" rx="2" ry="2"></rect><rect x="9" y="9" width="6" height="6"></rect><line x1="9" y1="1" x2="9" y2="4"></line><line x1="15" y1="1" x2="15" y2="4"></line><line x1="9" y1="20" x2="9" y2="23"></line><line x1="15" y1="20" x2="15" y2="23"></line><line x1="20" y1="9" x2="23" y2="9"></line><line x1="20" y1="14" x2="23" y2="14"></line><line x1="1" y1="9" x2="4" y2="9"></line><line x1="1" y1="14" x2="4" y2="14"></line></svg>
                        <span><?php echo app('translator')->get('layout.dashboard'); ?></span>
                    </div>
                    <div>
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-right"><polyline points="9 18 15 12 9 6"></polyline></svg>
                    </div>
                </a>
                <ul class="collapse submenu list-unstyled" id="dashboard" data-parent="#accordionExample">
                    <li id="li-dashboard">
                        <a href="<?php echo e(route('admin.home')); ?>"><?php echo app('translator')->get('layout.show'); ?></a>
                    </li>
                </ul>
            </li>


            
            <li class="menu">
                <a href="#users" data-toggle="collapse" data-active="false" aria-expanded="false" class="dropdown-toggle" id="toggle-users">
                    <div class="">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-cpu"><rect x="4" y="4" width="16" height="16" rx="2" ry="2"></rect><rect x="9" y="9" width="6" height="6"></rect><line x1="9" y1="1" x2="9" y2="4"></line><line x1="15" y1="1" x2="15" y2="4"></line><line x1="9" y1="20" x2="9" y2="23"></line><line x1="15" y1="20" x2="15" y2="23"></line><line x1="20" y1="9" x2="23" y2="9"></line><line x1="20" y1="14" x2="23" y2="14"></line><line x1="1" y1="9" x2="4" y2="9"></line><line x1="1" y1="14" x2="4" y2="14"></line></svg>
                        <span><?php echo app('translator')->get('layout.users'); ?></span>
                    </div>
                    <div>
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-right"><polyline points="9 18 15 12 9 6"></polyline></svg>
                    </div>
                </a>
                <ul class="collapse submenu list-unstyled" id="users" data-parent="#accordionExample">
                    <li id="li-users">
                        <a href="<?php echo e(route('admin.users.index')); ?>"><?php echo app('translator')->get('layout.show users'); ?></a>
                    </li>
                    <li id="li-create">
                        <a href="<?php echo e(route('admin.users.create')); ?>"><?php echo app('translator')->get('layout.add user'); ?></a>
                    </li>
                    <li id="li-trash">
                        <a href="<?php echo e(route('admin.users.trash')); ?>"><?php echo app('translator')->get('layout.trash'); ?></a>
                    </li>
                </ul>
            </li>

            
            <li class="menu">
                <a href="#roles" data-toggle="collapse" data-active="false" aria-expanded="false" class="dropdown-toggle" id="toggle-roles">
                    <div class="">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-cpu"><rect x="4" y="4" width="16" height="16" rx="2" ry="2"></rect><rect x="9" y="9" width="6" height="6"></rect><line x1="9" y1="1" x2="9" y2="4"></line><line x1="15" y1="1" x2="15" y2="4"></line><line x1="9" y1="20" x2="9" y2="23"></line><line x1="15" y1="20" x2="15" y2="23"></line><line x1="20" y1="9" x2="23" y2="9"></line><line x1="20" y1="14" x2="23" y2="14"></line><line x1="1" y1="9" x2="4" y2="9"></line><line x1="1" y1="14" x2="4" y2="14"></line></svg>
                        <span><?php echo app('translator')->get('layout.roles'); ?></span>
                    </div>
                    <div>
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-right"><polyline points="9 18 15 12 9 6"></polyline></svg>
                    </div>
                </a>
                <ul class="collapse submenu list-unstyled" id="roles" data-parent="#accordionExample">
                    <li id="li-roles">
                        <a href="<?php echo e(route('admin.roles.index')); ?>"><?php echo app('translator')->get('layout.show roles'); ?></a>
                    </li>
                    <li id="li-create">
                        <a href="<?php echo e(route('admin.roles.create')); ?>"><?php echo app('translator')->get('layout.add role'); ?></a>
                    </li>
                    <li id="li-trash">
                        <a href="<?php echo e(route('admin.roles.trash')); ?>"><?php echo app('translator')->get('layout.trash'); ?></a>
                    </li>
                </ul>
            </li>

            
            <li class="menu">
                <a href="#admins" data-toggle="collapse" data-active="false" aria-expanded="false" class="dropdown-toggle" id="toggle-admins">
                    <div class="">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-cpu"><rect x="4" y="4" width="16" height="16" rx="2" ry="2"></rect><rect x="9" y="9" width="6" height="6"></rect><line x1="9" y1="1" x2="9" y2="4"></line><line x1="15" y1="1" x2="15" y2="4"></line><line x1="9" y1="20" x2="9" y2="23"></line><line x1="15" y1="20" x2="15" y2="23"></line><line x1="20" y1="9" x2="23" y2="9"></line><line x1="20" y1="14" x2="23" y2="14"></line><line x1="1" y1="9" x2="4" y2="9"></line><line x1="1" y1="14" x2="4" y2="14"></line></svg>
                        <span><?php echo app('translator')->get('layout.admins'); ?></span>
                    </div>
                    <div>
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-right"><polyline points="9 18 15 12 9 6"></polyline></svg>
                    </div>
                </a>
                <ul class="collapse submenu list-unstyled" id="admins" data-parent="#accordionExample">
                    <li id="li-admins">
                        <a href="<?php echo e(route('admin.admins.index')); ?>"><?php echo app('translator')->get('layout.show admins'); ?></a>
                    </li>
                    <li id="li-create">
                        <a href="<?php echo e(route('admin.admins.create')); ?>"><?php echo app('translator')->get('layout.add Admin'); ?></a>
                    </li>
                    <li id="li-trash">
                        <a href="<?php echo e(route('admin.admins.trash')); ?>"><?php echo app('translator')->get('layout.trash'); ?></a>
                    </li>
                </ul>
            </li>


            <li class="menu">
                <a href="#sections" data-toggle="collapse" data-active="false" aria-expanded="false" class="dropdown-toggle" id="toggle-sections">
                    <div class="">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-cpu"><rect x="4" y="4" width="16" height="16" rx="2" ry="2"></rect><rect x="9" y="9" width="6" height="6"></rect><line x1="9" y1="1" x2="9" y2="4"></line><line x1="15" y1="1" x2="15" y2="4"></line><line x1="9" y1="20" x2="9" y2="23"></line><line x1="15" y1="20" x2="15" y2="23"></line><line x1="20" y1="9" x2="23" y2="9"></line><line x1="20" y1="14" x2="23" y2="14"></line><line x1="1" y1="9" x2="4" y2="9"></line><line x1="1" y1="14" x2="4" y2="14"></line></svg>
                        <span><?php echo app('translator')->get('layout.sections'); ?></span>
                    </div>
                    <div>
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-right"><polyline points="9 18 15 12 9 6"></polyline></svg>
                    </div>
                </a>
                <ul class="collapse submenu list-unstyled" id="sections" data-parent="#accordionExample">
                    <li id="li-sections">
                        <a href="<?php echo e(route('admin.sections.index')); ?>"><?php echo app('translator')->get('layout.show sections'); ?></a>
                    </li>
                    <li id="li-create">
                        <a href="<?php echo e(route('admin.sections.create')); ?>"><?php echo app('translator')->get('layout.add section'); ?></a>
                    </li>
                    <li id="li-trash">
                        <a href="<?php echo e(route('admin.sections.trash')); ?>"><?php echo app('translator')->get('layout.trash'); ?></a>
                    </li>
                    <li id="li-sort">
                        <a href="<?php echo e(route('admin.sections.sort.show')); ?>"><?php echo app('translator')->get('layout.sort sections'); ?></a>
                    </li>
                </ul>
            </li>


            <li class="menu">
                <a href="#categories" data-toggle="collapse" data-active="false" aria-expanded="false" class="dropdown-toggle" id="toggle-categories">
                    <div class="">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-cpu"><rect x="4" y="4" width="16" height="16" rx="2" ry="2"></rect><rect x="9" y="9" width="6" height="6"></rect><line x1="9" y1="1" x2="9" y2="4"></line><line x1="15" y1="1" x2="15" y2="4"></line><line x1="9" y1="20" x2="9" y2="23"></line><line x1="15" y1="20" x2="15" y2="23"></line><line x1="20" y1="9" x2="23" y2="9"></line><line x1="20" y1="14" x2="23" y2="14"></line><line x1="1" y1="9" x2="4" y2="9"></line><line x1="1" y1="14" x2="4" y2="14"></line></svg>
                        <span><?php echo app('translator')->get('layout.categories'); ?></span>
                    </div>
                    <div>
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-right"><polyline points="9 18 15 12 9 6"></polyline></svg>
                    </div>
                </a>
                <ul class="collapse submenu list-unstyled" id="categories" data-parent="#accordionExample">
                    <li id="li-categories">
                        <a href="<?php echo e(route('admin.categories.index')); ?>"><?php echo app('translator')->get('layout.show categories'); ?></a>
                    </li>
                    <li id="li-create">
                        <a href="<?php echo e(route('admin.categories.create')); ?>"><?php echo app('translator')->get('layout.add category'); ?></a>
                    </li>
                    <li id="li-trash">
                        <a href="<?php echo e(route('admin.categories.trash')); ?>"><?php echo app('translator')->get('layout.trash'); ?></a>
                    </li>
                    <li id="li-sort">
                        <a href="<?php echo e(route('admin.categories.sort.show')); ?>"><?php echo app('translator')->get('layout.sort categories'); ?></a>
                    </li>
                </ul>
            </li>


            <!-- /////////// شرائح العرض /////////// -->
            <li class="menu">
                <a href="#sliders" data-toggle="collapse" data-active="false" aria-expanded="false" class="dropdown-toggle" id="toggle-sliders">
                    <div class="">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-cpu"><rect x="4" y="4" width="16" height="16" rx="2" ry="2"></rect><rect x="9" y="9" width="6" height="6"></rect><line x1="9" y1="1" x2="9" y2="4"></line><line x1="15" y1="1" x2="15" y2="4"></line><line x1="9" y1="20" x2="9" y2="23"></line><line x1="15" y1="20" x2="15" y2="23"></line><line x1="20" y1="9" x2="23" y2="9"></line><line x1="20" y1="14" x2="23" y2="14"></line><line x1="1" y1="9" x2="4" y2="9"></line><line x1="1" y1="14" x2="4" y2="14"></line></svg>
                        <span><?php echo app('translator')->get('layout.sliders'); ?></span>
                    </div>
                    <div>
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-right"><polyline points="9 18 15 12 9 6"></polyline></svg>
                    </div>
                </a>
                <ul class="collapse submenu list-unstyled" id="sliders" data-parent="#accordionExample">
                    <li id="li-sliders">
                        <a href="<?php echo e(route('admin.sliders.index')); ?>"><?php echo app('translator')->get('layout.show sliders'); ?></a>
                    </li>
                    <li id="li-create">
                        <a href="<?php echo e(route('admin.sliders.create')); ?>"><?php echo app('translator')->get('layout.add slider'); ?></a>
                    </li>
                </ul>
            </li>

            
            <li class="menu">
                <a href="#staticPages" data-toggle="collapse" data-active="false" aria-expanded="false" class="dropdown-toggle" id="toggle-staticPages">
                    <div class="">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-cpu"><rect x="4" y="4" width="16" height="16" rx="2" ry="2"></rect><rect x="9" y="9" width="6" height="6"></rect><line x1="9" y1="1" x2="9" y2="4"></line><line x1="15" y1="1" x2="15" y2="4"></line><line x1="9" y1="20" x2="9" y2="23"></line><line x1="15" y1="20" x2="15" y2="23"></line><line x1="20" y1="9" x2="23" y2="9"></line><line x1="20" y1="14" x2="23" y2="14"></line><line x1="1" y1="9" x2="4" y2="9"></line><line x1="1" y1="14" x2="4" y2="14"></line></svg>
                        <span><?php echo app('translator')->get('layout.blocks'); ?></span>
                    </div>
                    <div>
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-right"><polyline points="9 18 15 12 9 6"></polyline></svg>
                    </div>
                </a>
                <ul class="collapse submenu list-unstyled" id="staticPages" data-parent="#accordionExample">
                    <li id="li-staticPages">
                        <a href="<?php echo e(route('admin.staticPages.index')); ?>"><?php echo app('translator')->get('layout.show'); ?></a>
                    </li>
                </ul>
            </li>

            
            <li class="menu">
                <a href="#services" data-toggle="collapse" data-active="false" aria-expanded="false" class="dropdown-toggle" id="toggle-services">
                    <div class="">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-cpu"><rect x="4" y="4" width="16" height="16" rx="2" ry="2"></rect><rect x="9" y="9" width="6" height="6"></rect><line x1="9" y1="1" x2="9" y2="4"></line><line x1="15" y1="1" x2="15" y2="4"></line><line x1="9" y1="20" x2="9" y2="23"></line><line x1="15" y1="20" x2="15" y2="23"></line><line x1="20" y1="9" x2="23" y2="9"></line><line x1="20" y1="14" x2="23" y2="14"></line><line x1="1" y1="9" x2="4" y2="9"></line><line x1="1" y1="14" x2="4" y2="14"></line></svg>
                        <span><?php echo app('translator')->get('layout.services'); ?></span>
                    </div>
                    <div>
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-right"><polyline points="9 18 15 12 9 6"></polyline></svg>
                    </div>
                </a>
                <ul class="collapse submenu list-unstyled" id="services" data-parent="#accordionExample">
                    <li id="li-services">
                        <a href="<?php echo e(route('admin.services.index')); ?>"><?php echo app('translator')->get('layout.show services'); ?></a>
                    </li>
                    <li id="li-create">
                        <a href="<?php echo e(route('admin.services.create')); ?>"><?php echo app('translator')->get('layout.add service'); ?></a>
                    </li>
                    <li id="li-trash">
                        <a href="<?php echo e(route('admin.services.trash')); ?>"><?php echo app('translator')->get('layout.trash'); ?></a>
                    </li>
                </ul>
            </li>

            
            <li class="menu">
                <a href="#projects" data-toggle="collapse" data-active="false" aria-expanded="false" class="dropdown-toggle" id="toggle-projects">
                    <div class="">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-cpu"><rect x="4" y="4" width="16" height="16" rx="2" ry="2"></rect><rect x="9" y="9" width="6" height="6"></rect><line x1="9" y1="1" x2="9" y2="4"></line><line x1="15" y1="1" x2="15" y2="4"></line><line x1="9" y1="20" x2="9" y2="23"></line><line x1="15" y1="20" x2="15" y2="23"></line><line x1="20" y1="9" x2="23" y2="9"></line><line x1="20" y1="14" x2="23" y2="14"></line><line x1="1" y1="9" x2="4" y2="9"></line><line x1="1" y1="14" x2="4" y2="14"></line></svg>
                        <span><?php echo app('translator')->get('layout.projects'); ?></span>
                    </div>
                    <div>
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-right"><polyline points="9 18 15 12 9 6"></polyline></svg>
                    </div>
                </a>
                <ul class="collapse submenu list-unstyled" id="projects" data-parent="#accordionExample">
                    <li id="li-projects">
                        <a href="<?php echo e(route('admin.projects.index')); ?>"><?php echo app('translator')->get('layout.show projects'); ?></a>
                    </li>
                    <li id="li-create">
                        <a href="<?php echo e(route('admin.projects.create')); ?>"><?php echo app('translator')->get('layout.add project'); ?></a>
                    </li>
                    <li id="li-trash">
                        <a href="<?php echo e(route('admin.projects.trash')); ?>"><?php echo app('translator')->get('layout.trash'); ?></a>
                    </li>
                </ul>
            </li>


            
            <li class="menu">
                <a href="#pages" data-toggle="collapse" data-active="false" aria-expanded="false" class="dropdown-toggle" id="toggle-pages">
                    <div class="">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-cpu"><rect x="4" y="4" width="16" height="16" rx="2" ry="2"></rect><rect x="9" y="9" width="6" height="6"></rect><line x1="9" y1="1" x2="9" y2="4"></line><line x1="15" y1="1" x2="15" y2="4"></line><line x1="9" y1="20" x2="9" y2="23"></line><line x1="15" y1="20" x2="15" y2="23"></line><line x1="20" y1="9" x2="23" y2="9"></line><line x1="20" y1="14" x2="23" y2="14"></line><line x1="1" y1="9" x2="4" y2="9"></line><line x1="1" y1="14" x2="4" y2="14"></line></svg>
                        <span><?php echo app('translator')->get('layout.pages'); ?></span>
                    </div>
                    <div>
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-right"><polyline points="9 18 15 12 9 6"></polyline></svg>
                    </div>
                </a>
                <ul class="collapse submenu list-unstyled" id="pages" data-parent="#accordionExample">
                    <li id="li-pages">
                        <a href="<?php echo e(route('admin.pages.index')); ?>"><?php echo app('translator')->get('layout.show pages'); ?></a>
                    </li>
                    <li id="li-create">
                        <a href="<?php echo e(route('admin.pages.create')); ?>"><?php echo app('translator')->get('layout.add page'); ?></a>
                    </li>
                    <li id="li-trash">
                        <a href="<?php echo e(route('admin.pages.trash')); ?>"><?php echo app('translator')->get('layout.trash'); ?></a>
                    </li>
                </ul>
            </li>


            
            <li class="menu">
                <a href="#contacts" data-toggle="collapse" data-active="false" aria-expanded="false" class="dropdown-toggle" id="toggle-contacts">
                    <div class="">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-cpu"><rect x="4" y="4" width="16" height="16" rx="2" ry="2"></rect><rect x="9" y="9" width="6" height="6"></rect><line x1="9" y1="1" x2="9" y2="4"></line><line x1="15" y1="1" x2="15" y2="4"></line><line x1="9" y1="20" x2="9" y2="23"></line><line x1="15" y1="20" x2="15" y2="23"></line><line x1="20" y1="9" x2="23" y2="9"></line><line x1="20" y1="14" x2="23" y2="14"></line><line x1="1" y1="9" x2="4" y2="9"></line><line x1="1" y1="14" x2="4" y2="14"></line></svg>
                        <span><?php echo app('translator')->get('layout.contacts'); ?></span>
                    </div>
                    <div>
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-right"><polyline points="9 18 15 12 9 6"></polyline></svg>
                    </div>
                </a>
                <ul class="collapse submenu list-unstyled" id="contacts" data-parent="#accordionExample">
                    <li id="li-contacts">
                        <a href="<?php echo e(route('admin.contacts.index')); ?>"><?php echo app('translator')->get('layout.show contacts'); ?></a>
                    </li>
                    <li id="li-create">
                        <a href="<?php echo e(route('admin.contacts.create')); ?>"><?php echo app('translator')->get('layout.add contact'); ?></a>
                    </li>
                    <li id="li-trash">
                        <a href="<?php echo e(route('admin.contacts.trash')); ?>"><?php echo app('translator')->get('layout.trash'); ?></a>
                    </li>
                </ul>
            </li>


            
            <li class="menu">
                <a href="#newsletters" data-toggle="collapse" data-active="false" aria-expanded="false" class="dropdown-toggle" id="toggle-newsletters">
                    <div class="">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-cpu"><rect x="4" y="4" width="16" height="16" rx="2" ry="2"></rect><rect x="9" y="9" width="6" height="6"></rect><line x1="9" y1="1" x2="9" y2="4"></line><line x1="15" y1="1" x2="15" y2="4"></line><line x1="9" y1="20" x2="9" y2="23"></line><line x1="15" y1="20" x2="15" y2="23"></line><line x1="20" y1="9" x2="23" y2="9"></line><line x1="20" y1="14" x2="23" y2="14"></line><line x1="1" y1="9" x2="4" y2="9"></line><line x1="1" y1="14" x2="4" y2="14"></line></svg>
                        <span><?php echo app('translator')->get('layout.newsletters'); ?></span>
                    </div>
                    <div>
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-right"><polyline points="9 18 15 12 9 6"></polyline></svg>
                    </div>
                </a>
                <ul class="collapse submenu list-unstyled" id="newsletters" data-parent="#accordionExample">
                    <li id="li-newsletters">
                        <a href="<?php echo e(route('admin.newsletters.index')); ?>"><?php echo app('translator')->get('layout.show newsletters'); ?></a>
                    </li>
                    <li id="li-trash">
                        <a href="<?php echo e(route('admin.newsletters.trash')); ?>"><?php echo app('translator')->get('layout.trash'); ?></a>
                    </li>
                </ul>
            </li>






















        </ul>

    </nav>

</div>
<?php /**PATH C:\xampp\htdocs\myCompany\resources\views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>