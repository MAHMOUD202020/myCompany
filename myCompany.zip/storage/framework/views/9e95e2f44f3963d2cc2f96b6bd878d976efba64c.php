<form action="<?php echo e(route('admin.permission.update' , $role->id)); ?>" method="post">
    <?php echo csrf_field(); ?>

    <table class="table table-hover">
        <thead>
        <tr>
            <th><?php echo app('translator')->get('form.label.name'); ?></th>
            <th><?php echo app('translator')->get('form.label.status'); ?></th>
        </tr>
        </thead>
        <tbody>
        <?php ($lastNameRole = ''); ?>

        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php ($permissionNow =  explode('.' ,  $permission->name)); ?>
            <?php if($permissionNow[0] !== $lastNameRole): ?>

                <tr>
                    <td class="title" colspan="2"><?php echo app('translator')->get("roles.title.".preg_replace("/.index/" , '' , $permissionNow[0] )); ?></td>
                </tr>
            <?php endif; ?>
            <tr>
                <th><?php echo app('translator')->get("roles.names.".$permissionNow[1]); ?></th>
                <td>
                    <div class="form-check">


                        <label class="switch  s-outline-danger mr-2">
                            <input  name="role_id[]" type="checkbox" value="<?php echo e($permission->id); ?>" <?php echo e(in_array($permission->name , $permissionChecked) ? 'checked'  : ''); ?> class="form-check-input">
                            <span class="slider round"></span>
                        </label>
                    </div>
                </td>
            </tr>
            <?php ($lastNameRole =  explode('.' , $permission->name)[0]); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <button class="btn btn-info mt-5 d-block m-auto w-100 font-weight-bold"><?php echo app('translator')->get('form.label.edit permission'); ?></button>
</form>
<?php /**PATH C:\xampp\htdocs\myCompany\resources\views/admin/pages/permission/form.blade.php ENDPATH**/ ?>