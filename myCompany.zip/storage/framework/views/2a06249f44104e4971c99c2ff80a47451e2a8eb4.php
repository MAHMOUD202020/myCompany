<?php $__env->startSection('content'); ?>

    <br>
    <div class="bg-light p-3 mb-2"><h2><?php echo app('translator')->get('form.label.whyChooseUs'); ?></h2></div>

    <?php echo $__env->make('admin.includes.alert_success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('admin.pages.homePage.whyChooseUs.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('admin.pages.homePage.whyChooseUs.show', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myCompany\resources\views/admin/pages/homePage/whyChooseUs/index.blade.php ENDPATH**/ ?>