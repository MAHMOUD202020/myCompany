<!-- Start Banner Area -->
<div class="main-banner-area">
    <div class="home-sliders owl-carousel owl-theme">
        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="home-item item" style='background-image: url("<?php echo e(asset("assets/web/images/slider/$slider->background")); ?>")'>
                <div class="d-table">
                    <div class="d-table-cell">
                        <div class="container">
                            <div class="main-banner-content">
                                <h1><?php echo e($slider->title); ?></h1>
                                <p><?php echo e($slider->text); ?></p>
                                <?php if($slider->btn_text): ?>
                                    <div class="banner-btn">
                                        <a href="<?php echo e($slider->url); ?>" class="default-btn"><?php echo e($slider->btn_text); ?></a>
                                    </div>
                                <?php endif; ?>

                            </div>

                            <div class="banner-image">
                                <img src="<?php echo e(asset('assets/web/images/slider/shape.png')); ?>" alt="image">

                                <img src="<?php echo e(asset("assets/web/images/slider/$slider->img")); ?>" class="banner-img" alt="image">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<!-- End Banner Area -->
<?php /**PATH C:\xampp\htdocs\myCompany\resources\views/web/pages/home/slider.blade.php ENDPATH**/ ?>