<!-- Start Preloader Area -->
<div class="preloader">
    <div class="preloader">
        <span></span>
        <span></span>
    </div>
</div>
<!-- End Preloader Area -->
<?php /**PATH C:\xampp\htdocs\myCompany\resources\views/web/layouts/preloader.blade.php ENDPATH**/ ?>