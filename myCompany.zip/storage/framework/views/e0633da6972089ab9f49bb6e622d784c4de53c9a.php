<div class="m-5">
    <div class="row">

        <div class="four col-md-6 mt-2">
            <a>
                <div class="counter-box colored "> <i class="fa fa-thumbs-o-up"></i> <span class="counter"><?php echo e($messages_count); ?></span>
                    <p><?php echo app('translator')->get('form.label.messages count'); ?></p>
                </div>
            </a>
        </div>

        <div class="four col-md-6 mt-2">
            <a>
                <div class="counter-box colored "> <i class="fa fa-thumbs-o-up"></i> <span class="counter"><?php echo e($messagesToday_count); ?></span>
                    <p><?php echo app('translator')->get('form.label.messages today count'); ?></p>
                </div>
            </a>
        </div>

        <div class="four col-md-6 mt-2">
            <a>
                <div class="counter-box colored "> <i class="fa fa-thumbs-o-up"></i> <span class="counter"><?php echo e($projects_count); ?></span>
                    <p><?php echo app('translator')->get('form.label.projects count'); ?></p>
                </div>
            </a>
        </div>

        <div class="four col-md-6 mt-2">
            <a>
                <div class="counter-box colored "> <i class="fa fa-thumbs-o-up"></i> <span class="counter"><?php echo e($services_count); ?></span>
                    <p><?php echo app('translator')->get('form.label.services count'); ?></p>
                </div>
            </a>
        </div>

        <div class="four col-md-6 mt-2">
            <a>
                <div class="counter-box colored "> <i class="fa fa-thumbs-o-up"></i> <span class="counter"><?php echo e($newsletters_count); ?></span>
                    <p><?php echo app('translator')->get('form.label.newsletters count'); ?></p>
                </div>
            </a>
        </div>

        <div class="four col-md-6 mt-2">
            <a>
                <div class="counter-box colored "> <i class="fa fa-thumbs-o-up"></i> <span class="counter"><?php echo e($newslettersToday_count); ?></span>
                    <p><?php echo app('translator')->get('form.label.newsletters today count'); ?></p>
                </div>
            </a>
        </div>

    </div>
</div>
<?php /**PATH C:\xampp\htdocs\myCompany\resources\views/admin/pages/dashboard/counter.blade.php ENDPATH**/ ?>