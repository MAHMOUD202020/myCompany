<link href="<?php echo e(asset('assets/Admin/css/loader.css')); ?>" rel="stylesheet" type="text/css" />
<link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700" rel="stylesheet">

<link rel="stylesheet" href="<?php echo e(asset("assets/Admin/bootstrap/css/bootstrap-$dir.min.css")); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/Admin/css/main.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/Admin/plugins/perfect-scrollbar/perfect-scrollbar.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/Admin/css/authentication/form-2.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/Admin/css/forms/theme-checkbox-radio.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/Admin/css/forms/switches.css')); ?>">
<link rel="shortcut icon" href="<?php echo e(asset('assets/Admin/images/favicon.png')); ?>" />

<style>
    .d-flex{
        direction: <?php echo e($dir); ?>;
    }
</style>

<?php echo $__env->yieldContent('css'); ?>
<?php /**PATH C:\xampp\htdocs\myCompany\resources\views/admin/includes/styleAuth.blade.php ENDPATH**/ ?>