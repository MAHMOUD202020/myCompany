<?php $__env->startSection('content'); ?>

    <!-- Start Page Title Area -->
    <div class="page-title-area item-bg-4" style='background-image: url("<?php echo e(asset("assets/web/images/pages/$page->cover")); ?>")'>
        <div class="d-table">
            <div class="d-table-cell">
                <div class="container">
                    <div class="page-title-content">
                        <h2><?php echo e($page->name); ?></h2>
                        <ul>
                            <li><a href="<?php echo e(route('web.home')); ?>"><?php echo app('translator')->get('layout.page-home'); ?></a></li>
                            <li><?php echo e($page->name); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Page Title Area -->


    <section class="protfolio-section pt-100 pb-100">
        <div class="container">
            <div class="section-title">
                <h2><?php echo e($block->title); ?></h2>
                <p><?php echo e($block->text); ?></p>
                <div class="bar"></div>
            </div>

            <div class="row">

                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6 col-sm-6">
                        <div class="single-protfolio">
                            <div class="image">
                                <a href="<?php echo e(route('web.projects.show' , $project->id)); ?>">
                                    <img src="<?php echo e(asset("assets/web/images/projects/$project->img")); ?>" alt="image">
                                </a>
                            </div>

                            <div class="content">
                                <a href="<?php echo e(route('web.projects.show' , $project->id)); ?>">
                                    <h3><?php echo e($project->name); ?></h3>
                                </a>
                                <a href="<?php echo e(route('web.projects.show' , $project->id)); ?>">
                                    <span><?php echo e($project->category); ?></span>
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-12 col-md-12">
                    <div class="pagination-area">
                        <?php echo $projects->links(); ?>

                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php echo $page->content; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.master' , ['title_seo' => $page->name], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myCompany\resources\views/web/pages/projects/index.blade.php ENDPATH**/ ?>