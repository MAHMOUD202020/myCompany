<!-- Start Navbar Area -->
<div class="navbar-area">
    <div class="fria-responsive-nav">
        <div class="container">
            <div class="fria-responsive-menu">
                <div class="logo">
                    <a href="<?php echo e(asset('/')); ?>">
                        <img src="<?php echo e(asset('assets/web/img/logo.png')); ?>" alt="logo">
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div class="fria-nav">
        <div class="container">
            <nav class="navbar navbar-expand-md navbar-light">
                <a class="navbar-brand" href="<?php echo e(asset('/')); ?>">
                    <img src="<?php echo e(asset('assets/web/img/logo.png')); ?>" alt="logo">
                </a>

                <div class="collapse navbar-collapse mean-menu" id="navbarSupportedContent">
                    <ul class="navbar-nav">

                        <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="nav-item">
                                <a href="<?php echo e($section->url); ?>" class="nav-link <?php echo e($section->url === request()->url() ? 'active' : ''); ?>">
                                    <?php echo e($section->name); ?>

                                    <?php if($section->subCategories->count() > 0): ?>
                                        <i class='bx bx-chevron-down'></i>
                                    <?php endif; ?>
                                </a>

                                <?php if($section->subCategories->count() > 0): ?>
                                    <ul class="dropdown-menu">

                                        <?php $__currentLoopData = $section->subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="nav-item">
                                                <a href="<?php echo e($subCategories->url); ?>" class="nav-link">
                                                    <?php echo e($subCategories->name); ?>

                                                </a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                <?php endif; ?>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <li class="nav-item bg-light">
                                <?php if($dir === 'rtl'): ?>
                                    <a  href="<?php echo e(route('web.lang.change' , 'en')); ?>" class="nav-link" style="padding-left: 8px">
                                        english
                                    </a>

                                <?php else: ?>
                                    <a href="<?php echo e(route('web.lang.change' , 'ar')); ?>" class="nav-link d-block" style="padding-right: 8px; width: 50px">
                                        عربي
                                    </a>
                                <?php endif; ?>

                            </li>
                    </ul>

                    <div class="others-options">
                        <div class="burger-menu">
                        </div>
                    </div>

                </div>
            </nav>
        </div>
    </div>
</div>
<!-- End Navbar Area -->
<?php /**PATH C:\xampp\htdocs\myCompany\resources\views/web/layouts/navbar.blade.php ENDPATH**/ ?>