
<!-- Start Video Section -->
<div class="video-section" style='background-image: url("<?php echo e(asset('assets/web/images/Website-Cover.jpg')); ?>")'>
    <div class="container">
        <div class="video-content">
            <a href="https://www.youtube.com/watch?v=YymWhauqjoA" class="video-btn popup-youtube">
                <i class="flaticon-play"></i>
            </a>
        </div>
    </div>
</div>
<!-- End Video Section -->
<?php /**PATH C:\xampp\htdocs\myCompany\resources\views/web/pages/home/vide.blade.php ENDPATH**/ ?>