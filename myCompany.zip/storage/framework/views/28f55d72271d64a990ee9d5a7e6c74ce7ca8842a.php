<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item active" aria-current="page"><span><?php echo app('translator')->get('layout.contacts'); ?></span></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('admin.includes.modalBtnAction', ['big' => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo myDataTable_button([
        __('layout.add contact') => route('admin.contacts.create'),
      ]); ?>


    <?php echo myDataTable_table([
        "id"         => 'id',
        "title_ar"   => __('form.label.title ar'),
        "title_en"   => __('form.label.title en'),
        "value"      => __('form.label.value'),
        "icon"       => __('form.label.icon'),
        "type"       => __('form.label.type'),
    ]); ?>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset("assets/myDataTable/data.css")); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset("assets/myDataTable/data.js")); ?>"></script>
    <script>

        colLg = 6;

        let type = {'contact':'<?php echo app('translator')->get('form.label.type contact'); ?>', 'social':'<?php echo app('translator')->get('form.label.type social'); ?>'}

        myDataTableColumns({
            name  :  ['id', 'title_ar', 'title_en', 'value', 'icon' , 'type'],
            class : {'updated_at': 'notEdit' , 'created_at': 'notEdit'},
            alias  : {type},
            select : {type},
            btn   :  {

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role' , 'contact.update')): ?>
                'edit': '<?php echo e(route('admin.contacts.update' , '')); ?>'+'/{id}',
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role' , 'contact.destroy')): ?>
                'delete': '<?php echo e(route('admin.contacts.destroy' , '')); ?>'+'/{id}',
                <?php endif; ?>
                'print': '#',
            }
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myCompany\resources\views/Admin/pages/contacts/index.blade.php ENDPATH**/ ?>