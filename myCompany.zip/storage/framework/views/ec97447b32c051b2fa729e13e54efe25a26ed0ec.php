<?php ($dir = app()->getLocale() === 'ar' ? 'rtl': 'ltr'); ?>

<!DOCTYPE html >
<html lang="<?php echo e(app()->getLocale()); ?>" dir="<?php echo e($dir); ?>">

<head>

    <!-- ///// meta ///// -->
    <?php echo $__env->make('admin.includes.meta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <title>elprof - admin</title>

    <!-- ///// style css ///// -->
    <?php echo $__env->make('admin.includes.styleAuth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

    <body class="<?php echo e($dir); ?> form">
         <div class="main-wrapper">

             <!-- ****** start page ****** -->
             <div class="page-wrapper">


                 <!-- start content -->
                 <div class="page-content">

                     <?php echo $__env->yieldContent('content'); ?>

                 </div>
                 <!-- end content -->

             </div>
         <!-- ****** end page ****** -->
         </div>
    </body>


<?php echo $__env->make('admin.includes.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script src="<?php echo e(asset('assets/Admin/js/authentication/form-2.js')); ?>"></script>

</html>
<?php /**PATH C:\xampp\htdocs\myCompany\resources\views/admin/masterAuth.blade.php ENDPATH**/ ?>