<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.contacts.index')); ?>"><?php echo app('translator')->get('layout.contacts'); ?></a></li>
    <li class="breadcrumb-item active" aria-current="page"><span><?php echo app('translator')->get('layout.add contact'); ?></span></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

        <?php echo $__env->make('admin.includes.alert_success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="row">
            <div id="flFormsGrid" class="col-lg-12 layout-spacing">
                <div class="statbox widget box box-shadow">
                    <div class="widget-header">
                        <div class="row">
                            <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                                <h4><?php echo app('translator')->get('layout.add contact'); ?></h4>
                            </div>
                        </div>
                    </div>
                    <div class="widget-content widget-content-area">
                        <?php echo $__env->make('admin.pages.contacts.form_create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>

    <script src="<?php echo e(asset('assets/Admin/plugins/bootstrap-maxlength/bootstrap-maxlength.js')); ?>"></script>

    <script>
        $('input').maxlength({
            threshold: 40,
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myCompany\resources\views/admin/pages/contacts/create.blade.php ENDPATH**/ ?>