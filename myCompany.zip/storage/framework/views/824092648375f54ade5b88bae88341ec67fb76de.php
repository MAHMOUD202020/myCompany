<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.roles.index')); ?>"><?php echo app('translator')->get('form.label.role'); ?></a></li>
    <li class="breadcrumb-item active" aria-current="page"><span><?php echo app('translator')->get('form.label.distribution permissions'); ?></span></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


    <a class="btn btn-info btnChecked selectAll mb-2 bg-dark mt-5"><?php echo app('translator')->get('form.label.select all'); ?></a>
    <div class="grid-margin stretch-card">
        <?php echo $__env->make('admin.includes.alert_success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="card">
            <div class="card-body">
                <h6 class="card-title bg-danger p-2"><?php echo app('translator')->get('form.label.distribution permissions of role'); ?><span class="text-white"> (<?php echo e($role['name']); ?>) </span></h6>
                <div class="table-responsive">
                    <?php echo $__env->make('admin.pages.permission.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $(function (){

            $('.btnChecked').on('click' , function (){

                if ($(this).hasClass('selectAll')) {
                    $('input').each(function () {

                        $(this).prop('checked', true)
                    })

                    $(this).removeClass('selectAll').addClass('deSelectAll').text('<?php echo app('translator')->get('form.label.deselect all'); ?>')

                }else {

                    if ($(this).hasClass('deSelectAll')) {

                        $('input').each(function () {

                            $(this).prop('checked', false)
                        })
                        $(this).addClass('selectAll').removeClass('deSelectAll').text('<?php echo app('translator')->get('form.label.select all'); ?>')

                    }
                }
            })
        });


    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <style>
        table .title {
            font-size: 20px;
            font-weight: bold;
            padding: 26px 0;
            background-color: #782c47;
            text-align: center;
            color: white !important;

        }

        .switch.s-outline-danger input:checked + .slider:before{

            top: 0 !important;
            right: 0 !important;
        }
    </style>

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/Admin/css/forms/switches.css')); ?>">

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myCompany\resources\views/admin/pages/permission/index.blade.php ENDPATH**/ ?>