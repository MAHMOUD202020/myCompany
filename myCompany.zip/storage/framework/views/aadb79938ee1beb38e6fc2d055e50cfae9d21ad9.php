<div class="action-center">
    <div class="">
        <div class="n-chk">
                <span class="new-control-indicator"></span><span><?php echo app('translator')->get('form.label.contact message'); ?></span>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\myCompany\resources\views/admin/pages/messages/btnAction.blade.php ENDPATH**/ ?>