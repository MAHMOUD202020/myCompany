<?php $__env->startSection('content'); ?>

    <!-- Start Page Title Area -->
    <div class="page-title-area item-bg-4" style='background-image: url("<?php echo e(asset("assets/web/images/pages/$page->cover")); ?>")'>
        <div class="d-table">
            <div class="d-table-cell">
                <div class="container">
                    <div class="page-title-content">
                        <h2><?php echo e($page->name); ?></h2>
                        <ul>
                            <li><a href="<?php echo e(route('web.home')); ?>"><?php echo app('translator')->get('layout.page-home'); ?></a></li>
                            <li><?php echo e($page->name); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Page Title Area -->


    <?php echo $__env->make('web.pages.home.services', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $page->content; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.master' , ['title_seo' => $page->name], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myCompany\resources\views/web/pages/services/index.blade.php ENDPATH**/ ?>