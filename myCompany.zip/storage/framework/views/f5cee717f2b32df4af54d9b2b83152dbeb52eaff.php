<?php $__env->startSection('breadcrumb'); ?>
    <?php if(!IS_TRASH): ?>
        <li class="breadcrumb-item active" aria-current="page"><span><?php echo app('translator')->get('layout.categories'); ?></span></li>
    <?php else: ?>
        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.categories.index')); ?>"><?php echo app('translator')->get('layout.categories'); ?></a></li>
        <li class="breadcrumb-item active" aria-current="page"><span><?php echo app('translator')->get('layout.trash'); ?></span></li>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('admin.includes.modalBtnAction' , ['big' => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo myDataTable_button([
        __('layout.add category') => route('admin.categories.create'),
      ]); ?>




    <?php echo myDataTable_table([
        "id"         => 'id',
        "name_ar"    => __('form.label.name ar'),
        "name_en"    => __('form.label.name en'),
        "slug"       => __('form.label.slug'),
        "parent_id"  => __('form.label.section'),
        "icon"        => __('form.label.icon'),
        "url"        => __('form.label.link'),
        "updated_at" => __('form.label.updated_at'),
    ]); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset("assets/myDataTable/data.css")); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset("assets/myDataTable/data.js")); ?>"></script>
    <script>

        let parent_id = '<?php echo json_encode($sections, 15, 512) ?>';

        colLg = 6;

        myDataTableColumns({
            name   :  ['id', 'name_ar', 'name_en', 'slug', 'parent_id', 'icon', 'url', 'updated_at'],
            class  : {'updated_at': 'notEdit' , 'created_at': 'notEdit'},
            file   : {'icon':'<?php echo e(asset('assets/Admin/images/categories/{icon}')); ?>'},
            alias  : {parent_id},
            select : {parent_id},
            btn    :  {

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role' , 'category.update')): ?>
                'edit'         : '<?php echo e(route('admin.categories.update' , '')); ?>'+'/{id}',
                <?php endif; ?>

                <?php if(!IS_TRASH): ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role' , 'category.destroy')): ?>
                    'delete'       : '<?php echo e(route('admin.categories.destroy' , '')); ?>'+'/{id}',
                    <?php endif; ?>

                <?php else: ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role' , 'category.restore')): ?>
                    'restore'      : '<?php echo e(route('admin.categories.restore' , '')); ?>'+'/{id}',
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role' , 'category.finalDelete')): ?>
                    'delete'       : '<?php echo e(route('admin.categories.finalDelete' , '')); ?>'+'/{id}',
                    <?php endif; ?>

                <?php endif; ?>
                'print'        : '#',

            }
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myCompany\resources\views/admin/pages/categories/index.blade.php ENDPATH**/ ?>