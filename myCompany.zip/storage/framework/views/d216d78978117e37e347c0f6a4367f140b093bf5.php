<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item active" aria-current="page"><span><?php echo app('translator')->get('layout.sliders'); ?></span></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


    <?php echo $__env->make('admin.includes.alert_success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('admin.pages.sliders.show', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('css'); ?>
    <style>

        .item-img{
            height: 400px;
            border: 1px solid;
            background-size:cover;
        }

        .item-background{
            margin-bottom: 15px;
            height: 150px;
            border: 1px solid;
            background-size:cover;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myCompany\resources\views/admin/pages/sliders/index.blade.php ENDPATH**/ ?>