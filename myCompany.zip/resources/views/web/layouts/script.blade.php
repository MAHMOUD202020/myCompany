<!-- Jquery Slim JS -->
<script src="{{asset('assets/web/js/jquery.min.js')}}"></script>
<!-- Popper JS -->
<script src="{{asset('assets/web/js/popper.min.js')}}"></script>
<!-- Bootstrap JS -->
<script src="{{asset('assets/web/js/bootstrap.min.js')}}"></script>
<!-- Meanmenu JS -->
<script src="{{asset('assets/web/js/jquery.meanmenu.js')}}"></script>
<!-- Owl Carousel JS -->
<script src="{{asset('assets/web/js/owl.carousel.js')}}"></script>
<!-- Magnific JS -->
<script src="{{asset('assets/web/js/jquery.magnific-popup.min.js')}}"></script>
<!-- Appear JS -->
<script src="{{asset('assets/web/js/jquery.appear.min.js')}}"></script>
<!-- Odometer JS -->
<script src="{{asset('assets/web/js/odometer.min.js')}}"></script>
<!-- Form Ajaxchimp JS -->
<script src="{{asset('assets/web/js/jquery.ajaxchimp.min.js')}}"></script>
<!-- Form Validator JS -->
<script src="{{asset('assets/web/js/form-validator.min.js')}}"></script>
<!-- Contact JS -->
<script src="{{asset('assets/web/js/contact-form-script.js')}}"></script>
<!-- Wow JS -->
<script src="{{asset('assets/web/js/wow.min.js')}}"></script>
<!-- Custom JS -->
<script src="{{asset('assets/web/js/main.js')}}"></script>
