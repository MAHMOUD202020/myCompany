<!-- Start Preloader Area -->
<div class="preloader">
    <div class="preloader">
        <span></span>
        <span></span>
    </div>
</div>
<!-- End Preloader Area -->
