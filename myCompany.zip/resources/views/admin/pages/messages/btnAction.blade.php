<div class="action-center">
    <div class="">
        <div class="n-chk">
                <span class="new-control-indicator"></span><span>@lang('form.label.contact message')</span>
        </div>
    </div>
</div>
